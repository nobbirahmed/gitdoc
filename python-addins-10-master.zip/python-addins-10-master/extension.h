/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once

#include "constants.h"
#include "utils.h"

class EditorExtensionUpdater
{
private:
  IEditorPtr m_ipEditor;
  py_obj m_pPyObject;
  bool m_clearAttrs;
public:
  EditorExtensionUpdater(PyObject* wrapObject, IEditorPtr ipWrapEditor, bool clearAttrsWhenFinished = false);
  ~EditorExtensionUpdater();
};

class ATL_NO_VTABLE wrap_extension:
	public CComObjectRootEx<CComSingleThreadModel>,
  public IExtension,
  public IExtensionConfig,
  public IDocumentEvents,
  public IPageIndexEvents,
  public IActiveViewEvents,
  public IEditEvents,
  public IEditEvents2,
  public IEditEvents3,
  public IEditEvents4,
  public IEditEvents5
{
  PyObject* m_pyObj;
  long m_eventDepth;
  // Doc event sink
  bool m_DocumentEvents;
  IConnectionHelperPtr m_ipDocEvents;
  IDocumentPtr m_ipDoc;

  // DDP event sink
  bool m_DDPEvents;
  IConnectionHelperPtr m_ipDDPEvents;
  IPageLayoutPtr m_ipPageLayout;

  // Active View event sink
  bool m_ActiveViewEvents;
  IConnectionHelperPtr m_ipActiveViewEvents;
  IActiveViewPtr m_ipActiveView;
  
  // Editor event sink
  bool m_EditEvents;
  IConnectionHelperPtr m_ipEditorEvents;
  IConnectionHelperPtr m_ipEditorEvents2;
  IConnectionHelperPtr m_ipEditorEvents3;
  IConnectionHelperPtr m_ipEditorEvents4;
  IConnectionHelperPtr m_ipEditorEvents5;

  void UnregisterDocumentSpecificEventSinks(bool ddp_only);
  void RegisterDocumentSpecificEventSinks(bool ddp_only);

  void RegisterEventSinks();
  void UnregisterEventSinks();

public:
  bstr_t m_id;
  bstr_t m_name;
  bstr_t m_description;
  VARIANT_BOOL m_showInDialog;
  IApplicationPtr m_ipApp;
  IEditorPtr m_ipEditor;

  wrap_extension() : m_pyObj(NULL),
                     m_eventDepth(0),
                     m_DocumentEvents(false),
                     m_DDPEvents(false),
                     m_ActiveViewEvents(false),
                     m_EditEvents(false),
                     m_showInDialog(VARIANT_TRUE)
	{
	}
  ~wrap_extension()
  {
    ATLASSERT(m_ipDocEvents == NULL);
    ATLASSERT(m_ipDDPEvents == NULL);
    ATLASSERT(m_ipActiveViewEvents == NULL);
    ATLASSERT(m_ipActiveViewEvents == NULL);
    Py_XDECREF(m_pyObj);
  }
  void setPy(PyObject* obj)
  { 
    ATLASSERT(m_pyObj == NULL);
    m_pyObj = obj; 
    Py_XINCREF(m_pyObj);
  }

  //IExtension
  STDMETHOD(get_Name) (BSTR * extensionName);
  STDMETHOD(Startup) (VARIANT * initializationData);
  STDMETHOD(Shutdown) ();
  //IExtensionConfig
  STDMETHOD(get_ProductName) (BSTR * Name);
  STDMETHOD(get_Description) (BSTR * Description);
  STDMETHOD(get_State) (esriExtensionState * State);
  STDMETHOD(put_State) (esriExtensionState State);
  //IDocumentEvents
  STDMETHOD(ActiveViewChanged) ( );
  STDMETHOD(MapsChanged) ( );
  STDMETHOD(OnContextMenu) (long x, long y, VARIANT_BOOL * handled );
  STDMETHOD(NewDocument) ( );
  STDMETHOD(OpenDocument) ( );
  STDMETHOD(BeforeCloseDocument) ( VARIANT_BOOL * abortClose );
  STDMETHOD(CloseDocument) ( );
  //IPageIndexEvents
  STDMETHOD(BeforePageIndexExtentChange) ( long oldID );
  STDMETHOD(PageIndexExtentChanged) ( long curID );
  STDMETHOD(BeforePageIndexRefresh) ( );
  STDMETHOD(PageIndexRefreshed) ( );
  //IActiveViewEvents
  STDMETHOD(ContentsChanged) ();
  STDMETHOD(ContentsCleared) ();
  STDMETHOD(ItemAdded) (VARIANT Item);
  STDMETHOD(ItemDeleted) (VARIANT Item);
  STDMETHOD(ItemReordered) (VARIANT Item, long toIndex);
  STDMETHOD(SelectionChanged) ();
  STDMETHOD(ViewRefreshed) (IActiveView * view, esriViewDrawPhase phase, VARIANT Data, IEnvelope * envelope);
  STDMETHOD(AfterDraw) (IDisplay * Display, esriViewDrawPhase phase);
  STDMETHOD(AfterItemDraw) (short Index, IDisplay * Display, esriDrawPhase phase);
  STDMETHOD(FocusMapChanged) ();
  STDMETHOD(SpatialReferenceChanged) ();
  //IEditEvents
  STDMETHOD(OnSelectionChanged) ();  
  STDMETHOD(OnCurrentLayerChanged) ();  
  STDMETHOD(OnCurrentTaskChanged) ();  
  STDMETHOD(OnSketchModified) ();  
  STDMETHOD(OnSketchFinished) ();  
  STDMETHOD(AfterDrawSketch) (IDisplay* pDpy);  
  STDMETHOD(OnStartEditing) ();  
  STDMETHOD(OnStopEditing) (VARIANT_BOOL save);  
  STDMETHOD(OnConflictsDetected) ();  
  STDMETHOD(OnUndo) ();  
  STDMETHOD(OnRedo) ();  
  STDMETHOD(OnCreateFeature) (IObject* obj);  
  STDMETHOD(OnChangeFeature) (IObject* obj);  
  STDMETHOD(OnDeleteFeature) (IObject* obj);
  //IEditEvents2
  STDMETHOD(OnCurrentZChanged) ();  
  STDMETHOD(OnVertexMoved) (IPoint* point);  
  STDMETHOD(OnVertexAdded) (IPoint* point);  
  STDMETHOD(OnVertexDeleted) (IPoint* point);  
  STDMETHOD(BeforeStopEditing) (VARIANT_BOOL save);  
  STDMETHOD(OnAbort) ();  
  STDMETHOD(OnStartOperation) ();  
  STDMETHOD(BeforeStopOperation) ();  
  STDMETHOD(OnStopOperation) ();  
  STDMETHOD(OnSaveEdits) ();
  //IEditEvents3
  STDMETHOD(BeforeDrawSketch) (IDisplay* pDpy);
  //IEditEvents4
  STDMETHOD(OnUseGroundToGridChanged) (VARIANT_BOOL g2g);  
  STDMETHOD(OnAngularCorrectionOffsetChanged) (double angOffset);  
  STDMETHOD(OnDistanceCorrectionFactorChanged) (double distFactor);
  //IEditEvents5
  STDMETHOD(OnCurrentTemplateChanged) (IEditTemplate* editTemplate);
  STDMETHOD(OnTemplatesRemoved) (IArray* editTemplates);
  STDMETHOD(OnTemplatesAdded) (IArray* editTemplates);
  STDMETHOD(OnTemplateModified) (IEditTemplate* editTemplate);
  STDMETHOD(OnVertexSelectionChanged) (); 
  STDMETHOD(OnShapeConstructorChanged) ();

BEGIN_COM_MAP(wrap_extension)
	COM_INTERFACE_ENTRY(IExtension)
  COM_INTERFACE_ENTRY_FUNC(IID_IExtensionConfig, 0, CONDITIONALQI)
  COM_INTERFACE_ENTRY(IDocumentEvents)
  COM_INTERFACE_ENTRY(IPageIndexEvents)
  COM_INTERFACE_ENTRY(IActiveViewEvents)
  COM_INTERFACE_ENTRY(IEditEvents)
  COM_INTERFACE_ENTRY(IEditEvents2)
  COM_INTERFACE_ENTRY(IEditEvents3)
  COM_INTERFACE_ENTRY(IEditEvents4)
  COM_INTERFACE_ENTRY(IEditEvents5)
END_COM_MAP()

  static HRESULT WINAPI CONDITIONALQI(void* pIn, REFIID riid, LPVOID* ppOut, DWORD_PTR dw)
  {
    wrap_extension* pExtension = static_cast<wrap_extension*>(pIn);

    if (riid == IID_IExtensionConfig)
    {
      if (pExtension->m_showInDialog == VARIANT_FALSE)
      {
        *ppOut = 0;
        return E_NOINTERFACE;
      }

      *ppOut = static_cast<IExtensionConfig*>(pExtension);
      pExtension->AddRef();
      return S_OK;
    }
    *ppOut = 0;
    return E_NOINTERFACE;
  }

  HRESULT FinalConstruct()
  {
    HRESULT hr = m_ipDocEvents.CreateInstance(CLSID_DocumentEventsHelper);
    if (hr != S_OK)
      return hr;
    hr = m_ipDDPEvents.CreateInstance(CLSID_PageIndexEventsHelper);
    if (hr != S_OK)
      return hr;
    hr = m_ipActiveViewEvents.CreateInstance(CLSID_ActiveViewEventsHelper);

    return hr;
  }
  void FinalRelease()
  {
    UnregisterEventSinks();
    m_ipDocEvents = 0;
    m_ipDDPEvents = 0;
    m_ipActiveViewEvents = 0;
  }
private:
  void ResetEditorAttributes();
};