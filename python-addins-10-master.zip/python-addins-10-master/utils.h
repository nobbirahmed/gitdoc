/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once
#include <list>
#include <algorithm>

class ATL_NO_VTABLE event_base
{
public:
  bool bind(const PyObject* pObj)
  {
    ATLASSERT(pObj);
    if (findIt(pObj) == m_binds.end())
    {
      m_binds.push_back(pObj);
      return true;
    }
    return false;
  }

  void unbind(const PyObject* pObj)
  {
    ATLASSERT(pObj);
    ATLASSERT(findIt(pObj) != m_binds.end());
    m_binds.remove(pObj);
    if (m_binds.empty())
      disconnect();
    m_ipEventHelper.Release();
  }

  void disconnect()
  {
    if (m_ipEventHelper && m_ipSource)
    {
      m_ipEventHelper->Unadvise(m_ipSource);
      m_ipSource.Release();
    }    
  }

  CComPtr<IUnknown> m_ipSource; 
protected:
   
  CComPtr<IConnectionHelper> m_ipEventHelper;  

  typedef std::list<const PyObject*> list_type;
  list_type::const_iterator findIt(const PyObject* ptr) const
  {
    return std::find(m_binds.begin(), m_binds.end(), ptr);
  }

  static void forward_call0(list_type& list,const char* method0);
  list_type m_binds; //weak refs
};

class ATL_NO_VTABLE control
{
private:
  typedef std::list<event_base*> container_type;
  container_type m_events;
protected:
  PyObject* m_pyObj;
  PyObject* m_pDict;
  bstr_t    m_id;

  control() : m_pyObj(NULL), m_pDict(NULL) {}
  ~control() 
  { 
    container_type::iterator it = m_events.begin();
    while (it != m_events.end())
    {
      ATLASSERT(*it);
      (*it)->unbind(m_pyObj);
      ++it;
    }
    Py_XDECREF(m_pyObj); 
  }

public:
  void initControl(const bstr_t& id, PyObject* obj, PyObject* pModuleDict);
  void bind(event_base* ptr)
  {
    ATLASSERT(ptr);
    if (ptr)
    {
      ptr->bind(m_pyObj);
      m_events.push_back(ptr);
    }
  }
  const PyObject* py() const { return m_pyObj; }
  const PyObject* pyDict() const { return m_pDict; }
  const char* id() const { return m_id; }
};


class ATL_NO_VTABLE py_obj
{
  PyObject* obj;
public:
  py_obj() : obj(NULL) { }
  //py_obj(int nil) : obj(NULL) { ATLASSERT(nil == 0); (void)nil; }
  py_obj(PyObject* o) : obj(o) { } //!!!! no addref
  py_obj(const py_obj& c) : obj(c.obj) { Py_XINCREF(obj); }
  
  ~py_obj()
  {
    Py_XDECREF(obj);
  }
    
  template<typename Q> operator const Q* () const 
  { 
    //make sure Q is an PyObject base type
    //typedef Q::_typeobject test_Q_type;

    C_ASSERT(sizeof(Q) >= sizeof(PyObject));
    _ASSERT( obj ? ((Q*)obj)->ob_type != NULL : true);
    return (const Q*)(obj); 
  }
  template<typename Q> operator Q* () const 
  { 
    //make sure Q is an PyObject base type
    //by casting to (Q*)(obj)->ob_type
    C_ASSERT(sizeof(Q) >= sizeof(PyObject));        
    _ASSERT( obj ? ((Q*)obj)->ob_type != NULL : true);
    return (Q*)(obj); 
  }

  //operator const PyObject* () const { return obj; }
  //operator PyObject* () const { return obj; }

  py_obj& operator = (PyObject* o)
  { 
    attach(o);
    return *this;
  }
  py_obj& operator = (const py_obj& c)
  {
    reset(c.obj);
    return *this;
  }

  void attach(PyObject* o)  
  {
    if (obj != o)
    {
      Py_XDECREF(obj);
      obj = o;
    }
  }
  PyObject* detach() { PyObject* o = obj; obj = NULL; return o; }
  void reset(PyObject* o = NULL)
  {
    if (obj != o)
    {
      Py_XINCREF(o);
      Py_XDECREF(obj);
      obj = o;
    }    
  }   
  //uncomment if needed
  //bool operator == (const py_obj& c) const { return obj == c.obj; }
  //bool operator != (const py_obj& c) const { return !(this->operator == (c)); }
  //bool operator != (const PyObject* o) const { return obj != o; }
  //bool operator == (const PyObject* o) const { return obj == o; }
  operator bool() const { return obj != NULL; }
  bool operator!() const { return obj == NULL; }
  bool isNull() const { return obj == NULL; }
};

namespace utils
{
  void dict_keys(PyObject* pDict);

  bool attr(PyObject* pObj, const char* attr, bstr_t &val);
  bool attr(PyObject* pObj, const char* attr, bool &val);
  bool attr(PyObject* pObj, const char* attr, long &val);
  const bstr_t toString(PyObject* pObj);
  py_obj call_member0(PyObject* pObj, const char* member);
  
  PyObject* create_object(PyTypeObject* type, void* ptrHost);
  void XYTOMapXY(long x, long y, double& mapx, double& mapy);

  void GetPythonWindow(IApplication* pApp, IGPCommandWindowAccessImpl **ppPyWin);
  PyObject* AsPythonGeometry(IGeometry* pGeometry);
  PyObject* AsPythonDataFrame(IMap* pMap);
  PyObject* AsPythonLayer(ILayer* pLayer);
  PyObject* VariantAsKnownPyObject(VARIANT var);

  class EventLock
  {
  public:
    EventLock(long* lockDepth):
        m_lockPtr(lockDepth)
    {
      ::InterlockedIncrement(m_lockPtr);
    }
    ~EventLock()
    {
      ::InterlockedDecrement(m_lockPtr);
    }
    bool OneDeep()
    {
      return (*m_lockPtr == 1);
    }
  private:
    long* m_lockPtr;
  };
};
