/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once

//base classes
#define commandBaseClass "CommandBase"
#define buttonClass      "ButtonClass"
#define toolClass        "ToolClass"
#define lineToolClass    "LineToolClass"
#define rectToolClass    "RectToolClass"
#define docEventsClass        "DocumentEventsClass"
#define activeViewEventsClass "ActiveViewEventsClass"

//common events map

#define s_startup                                "startup"
#define s_shutdown                               "shutdown"
#define s_enabled                                "enabled"
#define s_activeViewChanged                      "activeViewChanged"
#define s_mapsChanged                            "mapsChanged"
#define s_newDocument                            "newDocument"
#define s_openDocument                           "openDocument"
#define s_beforeCloseDocument                    "beforeCloseDocument"
#define s_closeDocument                          "closeDocument"
#define s_contextMenu                            "contextMenu"
#define s_beforePageIndexExtentChange            "beforePageIndexExtentChange"
#define s_pageIndexExtentChanged                 "pageIndexExtentChanged"
#define s_beforePageIndexRefresh                 "beforePageIndexRefresh"
#define s_pageIndexRefreshed                     "pageIndexRefreshed"
#define s_pageIndexRefresh                       "pageIndexRefresh"
#define s_contentsChanged                        "contentsChanged"
#define s_contentsCleared                        "contentsCleared"
#define s_itemAdded                              "itemAdded"
#define s_itemDeleted                            "itemDeleted"
#define s_itemReordered                          "itemReordered"
#define s_selectionChanged                       "selectionChanged"
#define s_focusMapChanged                        "focusMapChanged"
#define s_spatialReferenceChanged                "spatialReferenceChanged"
#define s_onCreate                               "onCreate"
#define s_onClick                                "onClick"
#define s_deactivate                             "deactivate"
#define s_onMouseDown                            "onMouseDown"
#define s_onMouseMove                            "onMouseMove"
#define s_onMouseUp                              "onMouseUp"
#define s_onMouseDownMap                         "onMouseDownMap"
#define s_onMouseMoveMap                         "onMouseMoveMap"
#define s_onMouseUpMap                           "onMouseUpMap"
#define s_onDblClick                             "onDblClick"
#define s_onKeyDown                              "onKeyDown"
#define s_onKeyUp                                "onKeyUp"
#define s_onDeactivate                           "deactivate"
#define s_onSelChange                            "onSelChange"
#define s_onEditChange                           "onEditChange"
#define s_onFocus                                "onFocus"
#define s_onEnter                                "onEnter"
#define s_onDestroy                              "onDestroy"
#define s_onCircle                               "onCircle"
#define s_onRectangle                            "onRectangle"
#define s_onLine                                 "onLine"
#define s_onEditorSelectionChanged               "onEditorSelectionChanged"
#define s_onCurrentLayerChanged                  "onCurrentLayerChanged"
#define s_onCurrentTaskChanged                   "onCurrentTaskChanged"
#define s_onSketchModified                       "onSketchModified"
#define s_onSketchFinished                       "onSketchFinished"
#define s_afterDrawSketch                        "afterDrawSketch"
#define s_onStartEditing                         "onStartEditing"
#define s_onStopEditing                          "onStopEditing"
#define s_onConflictsDetected                    "onConflictsDetected"
#define s_onUndo                                 "onUndo"
#define s_onRedo                                 "onRedo"
#define s_onCreateFeature                        "onCreateFeature"
#define s_onChangeFeature                        "onChangeFeature"
#define s_onDeleteFeature                        "onDeleteFeature"
#define s_onCurrentZChanged                      "onCurrentZChanged"
#define s_onVertexMoved                          "onVertexMoved"
#define s_onVertexAdded                          "onVertexAdded"
#define s_onVertexDeleted                        "onVertexDeleted"
#define s_beforeStopEditing                      "beforeStopEditing"
#define s_onAbort                                "onAbort"
#define s_onStartOperation                       "onStartOperation"
#define s_beforeStopOperation                    "beforeStopOperation"
#define s_onStopOperation                        "onStopOperation"
#define s_onSaveEdits                            "onSaveEdits"
#define s_beforeDrawSketch                       "beforeDrawSketch"
#define s_onUseGroundToGridChanged               "onUseGroundToGridChanged"
#define s_onAngularCorrectionOffsetChanged       "onAngularCorrectionOffsetChanged"
#define s_onDistanceCorrectionFactorChanged      "onDistanceCorrectionFactorChanged"
#define s_onCurrentTemplateChanged               "onCurrentTemplateChanged"
#define s_onTemplatesRemoved                     "onTemplatesRemoved"
#define s_onTemplatesAdded                       "onTemplatesAdded"
#define s_onTemplateModified                     "onTemplateModified"
#define s_onVertexSelectionChanged               "onVertexSelectionChanged"
#define s_onShapeConstructorChanged              "onShapeConstructorChanged"
#define s_HWND                                   "HWND"


//common attributes
#define s_items          "items"
#define s_editable       "editable"
#define s_hinttext       "hintText"
#define s_height         "height"
#define s_width          "width"
#define s_dropdownwidth  "dropdownWidth"
#define s_cursor         "cursor"
#define s_can_deactivate "canDeactivate"
#define s_value          "value"
#define s_name           "name"
#define s_caption        "caption"
#define s_editworkspace  "editWorkspace"
#define s_currentlayer   "currentLayer"
#define s_currentfeature "currentFeature"
#define s_editselection  "editSelection"


//progress dialog variable name
#define s_progressDialog "ProgressDialog"

#define ERROR_LOG_NAME  "error_log"
static const char s_debug_log_name[] = ERROR_LOG_NAME;