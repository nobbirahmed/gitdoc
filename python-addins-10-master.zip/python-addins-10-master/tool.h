/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once

#include "button.h"
#include "constants.h"

enum pythonAddinToolDrawMode
{
  drawToolAsNone,
  drawToolAsLine,
  drawToolAsRectangle,
  drawToolAsCircle
};

class ATL_NO_VTABLE wrap_tool:
	public CComObjectRootEx<CComSingleThreadModel>,
  public command_base<wrap_tool>,
  public ITool
{
protected:
  //friend class command_base<wrap_tool>;
  IMouseCursorPtr m_ipMouseCursor;
  ITrackerPtr m_ipTracker;
  IApplicationPtr m_ipApp;
public:

  ~wrap_tool()
  {
    if (m_ipMouseCursor)
      m_ipMouseCursor = 0;
  }

  //ICommand
  STDMETHOD(OnCreate)(IDispatch* pHook);
  //ITool
  STDMETHOD(get_Cursor)(ESRI_OLE_HANDLE * Cursor ){return E_NOTIMPL;}
  STDMETHOD(OnMouseDown)(long button, long shift, long x, long y );
  STDMETHOD(OnMouseMove) (long button, long shift, long x, long y );
  STDMETHOD(OnMouseUp) (long button, long shift, long x, long y );
  STDMETHOD(OnDblClick) ();
  STDMETHOD(OnKeyDown) (long keyCode, long shift );
  STDMETHOD(OnKeyUp) (long keyCode, long shift);
  STDMETHOD(OnContextMenu) (long x, long y,VARIANT_BOOL * handled){ return E_NOTIMPL;}
  STDMETHOD(Refresh) (ESRI_OLE_HANDLE hdc ){return S_OK;}
  STDMETHOD(Deactivate)(VARIANT_BOOL * complete );

BEGIN_COM_MAP(wrap_tool)
	COM_INTERFACE_ENTRY(ICommand)
  COM_INTERFACE_ENTRY(ITool)
END_COM_MAP()

	//DECLARE_PROTECT_FINAL_CONSTRUCT()
public:
  pythonAddinToolDrawMode m_drawMode;
};

/*
class ATL_NO_VTABLE draw_base
{
protected:
  CComQIPtr<IApplication> m_ipApp;

  //tracking objects
  CComPtr<IScreenDisplay> m_ipScreeen;
  CComQIPtr<IMxDocument> m_ipMxDoc;
  long m_tracking;

  draw_base() : m_tracking(0) {}
  ~draw_base()
  {
    ATLASSERT(m_ipMxDoc == NULL); //call end_tracking()
    ATLASSERT(m_ipScreeen == NULL);
    ATLASSERT(m_ipApp == NULL); //clean in FinalDestruc()
  }
  
  bool begin_tracking(long button)
  {
    ATLASSERT(m_ipApp);
    ATLASSERT(button);//not 0

    m_tracking = button;

    CComPtr<IDocument> ipDoc;
    m_ipApp->get_Document(&ipDoc);
    m_ipMxDoc = ipDoc;
    CComPtr<IActiveView> ipView;
    m_ipMxDoc->get_ActivatedView(&ipView);
    m_ipScreeen.Release();
    ipView->get_ScreenDisplay(&m_ipScreeen);
    m_ipScreeen->StartDrawing(0, esriNoScreenCache);
    return true;
  }

  void end_tracking()
  {
    ATLASSERT(m_tracking);//not 0
    m_ipScreeen->FinishDrawing();      
    m_ipScreeen->Invalidate(0, VARIANT_TRUE, esriNoScreenCache);
    //m_ipScreeen->UpdateWindow();
    m_ipScreeen.Release();
    m_ipMxDoc.Release();
    m_tracking = 0;
  }
  static bool get_rgb_attr(PyObject *pyObj, const char* attr, COLORREF &rgb);
};

template<class TBase, bool asLine = true>
class ATL_NO_VTABLE line_tool: public TBase, public draw_base
{
public:
  //line_tool(){}

  //HRESULT FinalConstruct()
  //{
  //  HRESULT hr = TBase::FinalConstruct();
  //  return hr;
  //}

  void FinalRelease()
  {
    m_ipPointCollection.Release();      
    m_ipApp.Release();
    m_ipSymbol.Release();

    TBase::FinalRelease();    
  }
  
  //override
  STDMETHOD(OnCreate)(IDispatch* pHook)
  {
    ATLASSERT(m_pyObj);
    m_ipApp = (IApplicationPtr)pHook;
    
    if (!m_ipSymbol && m_ipSymbol.CoCreateInstance(CLSID_SimpleLineSymbol) != S_OK)
      return E_FAIL;
      
    CComQIPtr<ISymbol>(m_ipSymbol)->put_ROP2(esriROPNotXOrPen);
      
    if (!m_ipPointCollection && m_ipPointCollection.CoCreateInstance(CLSID_Polyline) != S_OK)
      return E_FAIL;
    
    m_ipPointCollection->AddPoint(IPointPtr(CLSID_Point));
    m_ipPointCollection->AddPoint(IPointPtr(CLSID_Point));
    if (!asLine)
    {
      m_ipPointCollection->AddPoint(IPointPtr(CLSID_Point));
      m_ipPointCollection->AddPoint(IPointPtr(CLSID_Point));
      m_ipPointCollection->AddPoint(IPointPtr(CLSID_Point));
    }


    return TBase::OnCreate(pHook);
  }

  STDMETHOD(OnMouseDown)(long button, long shift, long x, long y )
  {
    if (button == 1 && begin_tracking(button))
    {            
      long width = 1;
      utils::attr(m_pyObj, s_Tool_width, width);      
      m_ipSymbol->put_Width(width);

      CComPtr<IColor> ipSelColor; ipSelColor.CoCreateInstance(CLSID_RgbColor);
      COLORREF rgb = RGB(255, 0 , 0);
      get_rgb_attr(m_pyObj, s_Tool_color, rgb);
      ipSelColor->put_RGB(rgb);
      m_ipSymbol->put_Color(ipSelColor);      

      if (PyObject_HasAttrString(m_pyObj, s_Tool_points))
        m_points = PyObject_GetAttrString(m_pyObj, s_Tool_points);

      if (!m_points.isNull() && PyList_Check(m_points))
      {
        if (PyList_GET_SIZE((PyObject*)m_points) != 4)
          m_points.reset();
      }
      else
        m_points.reset();

      CComPtr<ISpatialReference> ipSR;
      CComPtr<IDisplayTransformation> ipTransform;
      m_ipScreeen->get_DisplayTransformation(&ipTransform);
      ipTransform->get_SpatialReference(&ipSR);
    
      CComQIPtr<IGeometry>(m_ipPointCollection)->putref_SpatialReference(ipSR);
      CComPtr<IPoint> ipPoint;
      m_ipMxDoc->get_CurrentLocation(&ipPoint);

      if (!m_points.isNull())
      {
        double xy[2];
        ipPoint->QueryCoords(&xy[0], &xy[1]);
        PyList_SetItem(m_points, 0, PyFloat_FromDouble(xy[0]));
        PyList_SetItem(m_points, 1, PyFloat_FromDouble(xy[1]));
      }

      py_obj val = PyString_FromString("begin_tracking");
      PyObject_SetAttrString(m_pyObj, s_Tool_status, val);
      
      HRESULT hr = TBase::OnMouseDown(button, shift, x, y);

      if (!m_points.isNull())
      {
        //read coords back, user might change it
        //unsafe
        ipPoint->put_X(PyFloat_AS_DOUBLE(PyList_GET_ITEM((PyObject*)m_points, 0)));
        ipPoint->put_Y(PyFloat_AS_DOUBLE(PyList_GET_ITEM((PyObject*)m_points, 1)));
      }      
      
      m_ipPointCollection->UpdatePoint(0, ipPoint);
      m_ipPointCollection->UpdatePoint(1, ipPoint);
      
      if (!asLine)
      {
        m_ipPointCollection->UpdatePoint(2, ipPoint);
        m_ipPointCollection->UpdatePoint(3, ipPoint);
        m_ipPointCollection->UpdatePoint(4, ipPoint);
      }

      m_ipScreeen->SetSymbol(CComQIPtr<ISymbol>(m_ipSymbol));
      draw_now();
      return hr;
    }
    return TBase::OnMouseDown(button, shift, x, y);
  }

  STDMETHOD(OnMouseMove) (long button, long shift, long x, long y )
  {
    if (m_tracking == 1)
    {
      //clean old line
      draw_now();

      CComPtr<IPoint> ipPoint;
      m_ipMxDoc->get_CurrentLocation(&ipPoint);
      double xy[2];
      ipPoint->QueryCoords(&xy[0], &xy[1]);
              
      if (asLine)
        m_ipPointCollection->UpdatePoint(1, ipPoint);
      else
      {
        m_ipPointCollection->UpdatePoint(2, ipPoint);
        CComPtr<IPoint> ipPoint2;
        m_ipPointCollection->get_Point(1, &ipPoint2);
        ipPoint2->put_X(xy[0]);
        m_ipPointCollection->UpdatePoint(1, ipPoint2);
        ipPoint2.Release();
        m_ipPointCollection->get_Point(3, &ipPoint2);
        ipPoint2->put_Y(xy[1]);
        m_ipPointCollection->UpdatePoint(3, ipPoint2);
      }

      draw_now();

      m_ipScreeen->DrawCache(0, esriNoScreenCache, 0, 0);

      if (!m_points.isNull())
      {
        PyList_SetItem(m_points, 2, PyFloat_FromDouble(xy[0]));
        PyList_SetItem(m_points, 3, PyFloat_FromDouble(xy[1]));
      }
      py_obj val = PyString_FromString("tracking");
      PyObject_SetAttrString(m_pyObj, s_Tool_status, val);
      return S_OK;
    }
    return TBase::OnMouseMove(button, shift, x, y);
  }
  STDMETHOD(OnMouseUp)(long button, long shift, long x, long y )
  {
    if (m_tracking == 1)
    {
      //clean old line ??
      //m_ipScreeen->DrawPolyline(IPolylinePtr(m_ipPointCollection));
      
      //last position
      CComPtr<IPoint> ipPoint;
      m_ipMxDoc->get_CurrentLocation(&ipPoint);
      m_ipPointCollection->UpdatePoint(1, ipPoint);

      end_tracking();
      py_obj val = PyString_FromString("end_tracking");
      PyObject_SetAttrString(m_pyObj, s_Tool_status, val);
      //notify pythom object
      if (!m_points.isNull())
      {
        double xy[2];
        ipPoint->QueryCoords(&xy[0], &xy[1]);
        PyList_SetItem(m_points, 2, PyFloat_FromDouble(xy[0]));
        PyList_SetItem(m_points, 3, PyFloat_FromDouble(xy[1]));
        m_points.reset();
      }
    }
    HRESULT hr = TBase::OnMouseUp(button, shift, x, y);
    py_obj val = PyString_FromString("");
    PyObject_SetAttrString(m_pyObj, s_Tool_status, val);
    return hr;
  }
private:

  void draw_now()
  {
    m_ipScreeen->DrawPolyline(CComQIPtr<IPolyline>(m_ipPointCollection));
  }

  CComPtr<IPointCollection> m_ipPointCollection;
  CComPtr<ISimpleLineSymbol> m_ipSymbol;
  py_obj m_points;
};

typedef line_tool<wrap_tool, true> draw_line_tool;
typedef line_tool<wrap_tool, false> draw_rect_tool;


*/