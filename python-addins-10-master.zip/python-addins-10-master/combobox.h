/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#include "stdafx.h"
#include "button.h"
#include <vector>
#include <hash_map>

class ATL_NO_VTABLE wrap_combobox :
	public CComObjectRootEx<CComSingleThreadModel>,
  public command_base<wrap_combobox>,
  public IComboBox
{
  //friend class command_base<wrap_combobox>;
  IComboBoxHookPtr m_ipHook;
  long m_rowCount;
  long m_eventDepth;
  stdext::hash_map<long, py_obj> m_cookies;
  py_obj m_cachedItems;
public:

  wrap_combobox() : 
    m_ipHook(0),
    m_eventDepth(0),
    m_rowCount(3)
	{
	}
  ~wrap_combobox()
  {
  }

  void UpdateItems(bool force = true);

  //Override OnCreate
  STDMETHOD(OnCreate)(IDispatch* pHook);
  
  //IComboBox
  STDMETHOD(get_Editable)(VARIANT_BOOL * Editable);
  STDMETHOD(get_Width)(BSTR * stringForWidth);
  STDMETHOD(get_DropDownWidth)(BSTR * stringForWidth);
  STDMETHOD(get_DropDownHeight)(long * rowsHigh);
  STDMETHOD(get_HintText)(BSTR * HintText);
  STDMETHOD(OnSelChange)(long cookie);
  STDMETHOD(OnEditChange)(BSTR editString);
  STDMETHOD(OnFocus)(VARIANT_BOOL set);
  STDMETHOD(OnEnter)();
  STDMETHOD(get_ShowCaption)(VARIANT_BOOL * ShowCaption);

BEGIN_COM_MAP(wrap_combobox)
	COM_INTERFACE_ENTRY(ICommand)
  COM_INTERFACE_ENTRY(IComboBox)
END_COM_MAP()
};