/*
COPYRIGHT 1995-2014 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#include "stdafx.h"
#include "utils.h"
#include "ProgressDialog.h"

typedef struct ProgressDialogObject
{
    PyObject_HEAD
    int m_stackLevel;
    IProgressDialog2* m_pProgressDialog;
    ITrackCancel* m_pTrackCancel;
} ProgressDialogObject;

void ProgressDialogSanityCheck(ProgressDialogObject* self)
{
  if (!self)
  {
    return;
  }

  IApplicationPtr ipApp;
  HRESULT hr = ipApp.CreateInstance(CLSID_AppRef);

  if(FAILED(hr) || !ipApp)
  {
    PyErr_SetString(PyExc_RuntimeError, "Not running in a desktop application.");
    return;
  }

  ESRI_OLE_HANDLE hApp;
  ipApp->get_hWnd(&hApp);

  if (self->m_stackLevel > 0 && self->m_pProgressDialog == NULL)
  {
    ITrackCancelPtr ipTC(CLSID_CancelTracker);
    IProgressDialogFactoryPtr ipPF(CLSID_ProgressDialogFactory);
    IStepProgressorPtr ipSP;

    ipPF->Create(ipTC, hApp, &ipSP);

    IProgressDialog2Ptr ipDialog(ipSP);
    if (ipDialog)
    {
      ipDialog->AddRef();
      ipDialog->ShowDialog();
      self->m_pProgressDialog = ipDialog;

      if (self->m_pTrackCancel != 0)
      {
        self->m_pTrackCancel->Release();
        self->m_pTrackCancel = 0;
      }

      ipTC->AddRef();
      self->m_pTrackCancel = ipTC;
    }
  }
  else if (self->m_stackLevel <= 0)
  {
    if (self->m_pProgressDialog != NULL)
    {
      self->m_pProgressDialog->HideDialog();
      self->m_pProgressDialog->Release();
      self->m_pProgressDialog = 0;
    }

    if (self->m_pTrackCancel != NULL)
    {
      self->m_pTrackCancel->Release();
      self->m_pTrackCancel = 0;
    }
  }
}

static PyObject* ProgressDialogObject_new(PyTypeObject* type, PyObject* args, PyObject* kws)
{
  ProgressDialogObject* self((ProgressDialogObject *)type->tp_alloc(type, 0));
  if (self)
  {
    self->m_pProgressDialog = NULL;
    self->m_stackLevel = 0;
  }
  return (PyObject*)self;
}


static void ProgressDialogObject_dealloc(ProgressDialogObject* self)
{
  if (self->m_pProgressDialog != NULL)
  {
    self->m_pProgressDialog->Release();
    self->m_pProgressDialog = 0;
  }
  if (self->m_pTrackCancel != NULL)
  {
    self->m_pTrackCancel->Release();
    self->m_pTrackCancel = 0;
  }
  PyObject_DEL(self);
}


static PyObject* ProgressDialogObject_call(PyObject* self, PyObject* args, PyObject* kws)
{
  Py_IncRef(self);
  return self;
}


static PyObject* ProgressDialogObject___enter__(ProgressDialogObject* self, PyObject* args, PyObject* kws)
{
  (self->m_stackLevel)++;
  ProgressDialogSanityCheck(self);

  if (self->m_pProgressDialog && self->m_stackLevel > 0)
  {
    self->m_pProgressDialog->ShowDialog();

    IStepProgressorPtr ipProgressor(self->m_pProgressDialog);
    if (ipProgressor)
    {
      ipProgressor->Hide();
      ipProgressor->put_MinRange(0);
      ipProgressor->put_MaxRange(100);
    }
  }

  if (self->m_pProgressDialog)
  {
    PyObject* retVal((PyObject*)self);
    Py_INCREF(self);
    return retVal;
  }
  else
  {
    (self->m_stackLevel)--;
    ProgressDialogSanityCheck(self);

    if (!PyErr_Occurred())
    {
      PyErr_SetNone(PyExc_RuntimeError);
    }
    return NULL;
  }
}


static PyObject* ProgressDialogObject___exit__(ProgressDialogObject* self, PyObject* args, PyObject* kws)
{
  static char *kwlist[] = {"exc_type", "exc_value", "traceback", NULL};
  PyObject *arg_exc_type(0),
           *arg_exc_value(0),
           *arg_traceback(0);
  if (!PyArg_ParseTupleAndKeywords(args, kws, "OOO:ProgressDialog.__exit__", kwlist, &arg_exc_type, &arg_exc_value, &arg_traceback))
  {
    Py_RETURN_NONE;
  }

  if (PyErr_Occurred())
  {
    Py_RETURN_NONE;
  }

  (self->m_stackLevel)--;
  ProgressDialogSanityCheck(self);
  if (self->m_pProgressDialog && self->m_stackLevel <= 0)
  {
    self->m_pProgressDialog->HideDialog();
  }

  if (!PyErr_Occurred())
  {
    Py_RETURN_NONE;
  }
  else
  {
    return 0;
  }
}



static PyObject* ProgressDialogObject_getanimation(ProgressDialogObject* self, void*)
{
  if (self->m_pProgressDialog)
  {
    esriProgressAnimationTypes eAnimation;
    self->m_pProgressDialog->get_Animation(&eAnimation);

    Py_IncRef(Py_None);
    py_obj return_string(Py_None);

    switch(eAnimation)
    {
    case esriProgressGlobe:
      return_string = PyUnicode_FromString("Globe");
      break;
    case esriDownloadFile:
      return_string = PyUnicode_FromString("File");
      break;
    case esriProgressSpiral:
      return_string = PyUnicode_FromString("Spiral");
      break;
    case esriNoAnimation:
    default:
      break;
    }

    return return_string.detach();
  }

  PyErr_SetNone(PyExc_AttributeError);
  return NULL;
}

static int ProgressDialogObject_setanimation(ProgressDialogObject* self, PyObject* val, void*)
{
  if (self->m_pProgressDialog)
  {
    esriProgressAnimationTypes eAnimation(esriNoAnimation);
    if (PyObject_IsTrue(val))
    {
      _bstr_t stringVal(utils::toString(val));
      if (::_wcsicmp(stringVal, L"Globe") == 0)
      {
        eAnimation = esriProgressGlobe;
      }
      else if (::_wcsicmp(stringVal, L"File") == 0)
      {
        eAnimation = esriDownloadFile;
      }
      else if (::_wcsicmp(stringVal, L"Spiral") == 0)
      {
        eAnimation = esriProgressSpiral;
      }
      else
      {
        PyErr_SetObject(PyExc_ValueError, val);
        return -1;
      }
    }
    self->m_pProgressDialog->put_Animation(eAnimation);
    return 0;
  }

  PyErr_SetString(PyExc_AttributeError, "can't set attribute");
  return -1;
}



static PyObject* ProgressDialogObject_getcancelled(ProgressDialogObject* self, void*)
{
  if (self->m_pTrackCancel != NULL)
  {
    VARIANT_BOOL vbKeepGoing(VARIANT_TRUE);
    self->m_pTrackCancel->Continue(&vbKeepGoing);

    if (vbKeepGoing == VARIANT_FALSE)
    {
      Py_RETURN_TRUE;
    }
    else
    {
      Py_RETURN_FALSE;
    }
  }
  PyErr_SetNone(PyExc_AttributeError);
  return NULL;
}



static PyObject* ProgressDialogObject_getcanCancel(ProgressDialogObject* self, void*)
{
  if (self->m_pProgressDialog)
  {
    VARIANT_BOOL vbCanCancel(VARIANT_FALSE);
    self->m_pProgressDialog->get_CancelEnabled(&vbCanCancel);

    if (vbCanCancel == VARIANT_TRUE)
    {
      Py_RETURN_TRUE;
    }
    else
    {
      Py_RETURN_FALSE;
    }
  }

  PyErr_SetNone(PyExc_AttributeError);
  return NULL;
}

static int ProgressDialogObject_setcanCancel(ProgressDialogObject* self, PyObject* val, void*)
{
  if (self->m_pProgressDialog)
  {
    VARIANT_BOOL vbCanCancel(PyObject_IsTrue(val) ? VARIANT_TRUE : VARIANT_FALSE);
    self->m_pProgressDialog->put_CancelEnabled(vbCanCancel);
    return 0;
  }

  PyErr_SetString(PyExc_AttributeError, "can't set attribute");
  return -1;
}



static PyObject* ProgressDialogObject_getdescription(ProgressDialogObject* self, void*)
{
  if (self->m_pProgressDialog)
  {
    _bstr_t description;
    self->m_pProgressDialog->get_Description(at(description));

    return PyUnicode_FromWideChar(description, (Py_ssize_t)::SysStringLen(description));
  }

  PyErr_SetNone(PyExc_AttributeError);
  return NULL;
}

static int ProgressDialogObject_setdescription(ProgressDialogObject* self, PyObject* val, void*)
{
  if (self->m_pProgressDialog)
  {
    _bstr_t description(utils::toString(val));
    self->m_pProgressDialog->put_Description(description);

    return 0;
  }

  PyErr_SetString(PyExc_AttributeError, "can't set attribute");
  return -1;
}



static PyObject* ProgressDialogObject_getprogress(ProgressDialogObject* self, void*)
{
  IStepProgressorPtr ipProgressor(self->m_pProgressDialog);

  if (ipProgressor)
  {
    long position(-1);

    if (SUCCEEDED(ipProgressor->get_Position(&position)) && position != -1)
    {
      return PyInt_FromLong(position);
    }
    else if (position == -1)
    {
      Py_RETURN_NONE;
    }
  }

  PyErr_SetNone(PyExc_AttributeError);
  return NULL;
}

static int ProgressDialogObject_setprogress(ProgressDialogObject* self, PyObject* val, void*)
{
  IStepProgressorPtr ipProgressor(self->m_pProgressDialog);

  if (ipProgressor)
  {
    if (val == Py_None)
    {
      ipProgressor->Hide();
      return 0;
    }

    long position(PyInt_AsLong(val));
    if (PyErr_Occurred())
    {
      return -1;
    }

    if (position < 0)
    {
      position = 0;
    }
    else if (position > 100)
    {
      position = 100;
    }

    ipProgressor->Show();
    ipProgressor->put_Position(position);
    return 0;
  }

  PyErr_SetString(PyExc_AttributeError, "can't set attribute");
  return -1;
}



static PyObject* ProgressDialogObject_gettitle(ProgressDialogObject* self, void*)
{
  if (self->m_pProgressDialog)
  {
    _bstr_t title;
    self->m_pProgressDialog->get_Title(at(title));

    return PyUnicode_FromWideChar(title, (Py_ssize_t)::SysStringLen(title));
  }

  PyErr_SetNone(PyExc_AttributeError);
  return NULL;
}

static int ProgressDialogObject_settitle(ProgressDialogObject* self, PyObject* val, void*)
{
  if (self->m_pProgressDialog)
  {
    _bstr_t title(utils::toString(val));
    self->m_pProgressDialog->put_Title(title);

    return 0;
  }

  PyErr_SetString(PyExc_AttributeError, "can't set attribute");
  return -1;
}


// Slots and accessors for ProgressDialog

static PyMethodDef ProgressDialogObject_Methods[] = {
  {"__enter__", (PyCFunction)ProgressDialogObject___enter__, METH_NOARGS, "ProgressDialog.__enter__()"},
  {"__exit__", (PyCFunction)ProgressDialogObject___exit__, METH_VARARGS|METH_KEYWORDS, "ProgressDialog.__exit__(exc_type, exc_value, traceback)"},
  {NULL, NULL, NULL, NULL}
};

static PyGetSetDef ProgressDialogObject_GetSets[] = {
  {"animation", (getter)ProgressDialogObject_getanimation, (setter)ProgressDialogObject_setanimation, "animation", 0},
  {"cancelled", (getter)ProgressDialogObject_getcancelled, (setter)0, "cancelled", 0},
  {"canCancel", (getter)ProgressDialogObject_getcanCancel, (setter)ProgressDialogObject_setcanCancel, "canCancel", 0},
  {"description", (getter)ProgressDialogObject_getdescription, (setter)ProgressDialogObject_setdescription, "description", 0},
  {"progress", (getter)ProgressDialogObject_getprogress, (setter)ProgressDialogObject_setprogress, "progress", 0},
  {"title", (getter)ProgressDialogObject_gettitle, (setter)ProgressDialogObject_settitle, "title", 0},
  {NULL, NULL, NULL, NULL, NULL}
};

PyTypeObject ProgressDialogObject_Type = {
  PyObject_HEAD_INIT(&PyType_Type)
  0,                                             /*ob_size*/
  "ProgressDialogObject",                        /*tp_name*/
  sizeof(ProgressDialogObject),                  /*tp_basicsize*/
  0,                                             /*tp_itemsize*/
  (destructor)ProgressDialogObject_dealloc,      /*tp_dealloc*/
  0,                                             /*tp_print*/
  0,                                             /*tp_getattr*/
  0,                                             /*tp_setattr*/
  0,                                             /*tp_compare*/
  0,                                             /*tp_repr*/
  0,                                             /*tp_as_number*/
  0,                                             /*tp_as_sequence*/
  0,                                             /*tp_as_mapping*/
  0,                                             /*tp_hash*/
  ProgressDialogObject_call,                     /*tp_call*/
  0,                                             /*tp_str*/
  0,                                             /*tp_getattro*/
  0,                                             /*tp_setattro*/
  0,                                             /*tp_as_buffer*/
  Py_TPFLAGS_DEFAULT|Py_TPFLAGS_BASETYPE,        /*tp_flags*/
  "Progress Dialog Object",                      /*tp_doc*/
  0,                                             /*tp_traverse*/
  0,                                             /*tp_clear*/
  0,                                             /*tp_richcompare*/
  0,                                             /*tp_weaklistoffset*/
  0,                                             /*tp_iter*/
  0,                                             /*tp_iternext*/
  ProgressDialogObject_Methods,                  /*tp_methods*/
  0,                                             /*tp_members*/
  (PyGetSetDef*)ProgressDialogObject_GetSets,    /*tp_getset*/
  0,                                             /*tp_base*/
  0,                                             /*tp_dict*/
  0,                                             /*tp_descr_get*/
  0,                                             /*tp_descr_set*/
  0,                                             /*tp_dictoffset*/
  0,                                             /*tp_init*/
  0,                                             /*tp_alloc*/
  ProgressDialogObject_new                       /*tp_new*/
};

PyTypeObject* progressdialogpythonobject::GetProgressDialogType()
{
  return &ProgressDialogObject_Type;
}