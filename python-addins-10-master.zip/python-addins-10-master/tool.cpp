/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#include "StdAfx.h"
#include "tool.h"
#include "constants.h"

STDMETHODIMP wrap_tool::OnCreate(IDispatch* pHook)
{        
  IApplicationPtr ipApp(pHook);
  m_ipApp = ipApp;
  
  return command_base<wrap_tool>::OnCreate(pHook);
}

STDMETHODIMP wrap_tool::OnMouseDown(long button, long shift, long x, long y )
{
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onMouseDown))
  {
    PythonExecuteWait RunWrap;

    py_obj ret = PyObject_CallMethod(m_pyObj, s_onMouseDown, "iiii", x, y, button, shift);
  }
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onMouseDownMap))
  {
    PythonExecuteWait RunWrap;

    double mapx, mapy;
    utils::XYTOMapXY(x, y, mapx, mapy);
    py_obj ret = PyObject_CallMethod(m_pyObj, s_onMouseDownMap, "ddii", mapx, mapy, button, shift);
  }
  long set_cursor = 0;
  if (utils::attr(m_pyObj, s_cursor, set_cursor))
  {
    if (!m_ipMouseCursor)
      m_ipMouseCursor.CreateInstance(CLSID_MouseCursor);
    m_ipMouseCursor->SetCursor(_variant_t(set_cursor));
  }


  if ((!m_ipTracker) && m_drawMode != drawToolAsNone)
  {
    IGeometryPtr ipGeometryReturned;
    m_ipTracker.CreateInstance(CLSID_Tracker);

    VARIANT_BOOL inProgress(VARIANT_TRUE);
    if (m_ipTracker)
      m_ipTracker->get_InProgress(&inProgress);
    
    if (!inProgress)
    {

      esriTrackOption trackOption;
      char * method_name(0);

      switch(m_drawMode)
      {
      case drawToolAsCircle:
        trackOption = esriTrackCircle;
        method_name = s_onCircle;
        break;
      case drawToolAsRectangle:
        trackOption = esriTrackEnvelope;
        method_name = s_onRectangle;
        break;
      case drawToolAsLine:
      default:
        trackOption = esriTrackLine;
        method_name = s_onLine;
        break;
      }

      IAppDisplayPtr ipAppDisplay;
      IScreenDisplayPtr ipScreenDisplay;

      IMxApplication2Ptr ipMxApp(m_ipApp);

      if (ipMxApp)
        ipMxApp->get_Display(&ipAppDisplay);

      if (ipAppDisplay)
        ipAppDisplay->get_MainScreen(&ipScreenDisplay);

      if (ipScreenDisplay &&
          SUCCEEDED(m_ipTracker->Track(trackOption, ipScreenDisplay, &ipGeometryReturned)) &&
          ipGeometryReturned &&
          method_name &&
          PyObject_HasAttrString(m_pyObj, method_name))
      {
        PythonExecuteWait RunWrap;
        py_obj GeometryValue(utils::AsPythonGeometry((IGeometry*)ipGeometryReturned));
        py_obj method = PyObject_GetAttrString(m_pyObj, method_name);
        if (method)
        {
          py_obj args = Py_BuildValue("(O)", GeometryValue ? (PyObject*)GeometryValue : Py_None);
          py_obj ret = PyObject_Call((PyObject*)method, args, NULL);
        }

        if (PyErr_Occurred())
          PyErr_Print();
      }
            
    }

    m_ipTracker = 0;
  }
  return S_OK;
}

STDMETHODIMP wrap_tool::OnMouseMove(long button, long shift, long x, long y )
{
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onMouseMove))
  {
    PythonExecuteWaitNoCursor RunWrap;

    py_obj ret = PyObject_CallMethod(m_pyObj, s_onMouseMove, "iiii", x, y, button, shift);
  }
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onMouseMoveMap))
  {
    PythonExecuteWaitNoCursor RunWrap;

    double mapx, mapy;
    utils::XYTOMapXY(x, y, mapx, mapy);
    py_obj ret = PyObject_CallMethod(m_pyObj, s_onMouseMoveMap, "ddii", mapx, mapy, button, shift);
  }
  long set_cursor = 0;
  if (utils::attr(m_pyObj, s_cursor, set_cursor))
  {
    if (!m_ipMouseCursor)
      m_ipMouseCursor.CreateInstance(CLSID_MouseCursor);
    m_ipMouseCursor->SetCursor(_variant_t(set_cursor));
  }
  return S_OK;
}

STDMETHODIMP wrap_tool::OnMouseUp(long button, long shift, long x, long y )
{
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onMouseUp))
  {
    PythonExecuteWaitNoCursor RunWrap;

    py_obj ret = PyObject_CallMethod(m_pyObj, s_onMouseUp, "iiii", x, y, button, shift);
  }
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onMouseUpMap))
  {
    PythonExecuteWaitNoCursor RunWrap;

    double mapx, mapy;
    utils::XYTOMapXY(x, y, mapx, mapy);
    py_obj ret = PyObject_CallMethod(m_pyObj, s_onMouseUpMap, "ddii", mapx, mapy, button, shift);
  }
  if (m_ipMouseCursor)
    m_ipMouseCursor = 0;
  if (m_ipTracker)
    m_ipTracker = 0;
  return S_OK;
}

STDMETHODIMP wrap_tool::OnDblClick()
{
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onDblClick))
  {
    PythonExecuteWait RunWrap;

    py_obj ret = PyObject_CallMethod(m_pyObj, s_onDblClick, "", NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_tool::OnKeyDown (long keyCode, long shift )
{
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onKeyDown))
  {
    PythonExecuteWait RunWrap;

    py_obj ret = PyObject_CallMethod(m_pyObj, s_onKeyDown, "ii", keyCode, shift);
  }
  return S_OK;
}

STDMETHODIMP wrap_tool::OnKeyUp (long keyCode, long shift)
{
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onKeyUp))
  {
    PythonExecuteWait RunWrap;

    py_obj ret = PyObject_CallMethod(m_pyObj, s_onKeyUp, "ii", keyCode, shift);
  }
  return S_OK;
}

STDMETHODIMP wrap_tool::Deactivate(VARIANT_BOOL * complete )
{
  *complete = VARIANT_TRUE;
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_deactivate))
  {
    PythonExecuteWait RunWrap;

    py_obj ret = PyObject_CallMethod(m_pyObj, s_deactivate, NULL);
  }
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_can_deactivate))
  {
    py_obj active = PyObject_GetAttrString(m_pyObj, s_can_deactivate);
    *complete = PyObject_IsTrue(active) ? VARIANT_TRUE : VARIANT_FALSE;
  }
  if (m_ipMouseCursor)
    m_ipMouseCursor = 0;
  return S_OK;
}