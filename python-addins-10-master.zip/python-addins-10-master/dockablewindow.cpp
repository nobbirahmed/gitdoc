/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
// dockablewindow.cpp : Implementation of DockableWindow

#include "stdafx.h"
#include "dockablewindow.h"
#include "constants.h"
#include "utils.h"


STDMETHODIMP wrap_dockablewindow::OnCreate(IDispatch * hook )
{ 
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onCreate))
    py_obj ret = PyObject_CallMethod(m_pyObj, s_onCreate, "", NULL);
  return S_OK;
}

STDMETHODIMP wrap_dockablewindow::get_ChildHWND(ESRI_OLE_HANDLE * hWnd)
{
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_HWND))
  {
    py_obj HWNDObject(PyObject_GetAttrString(m_pyObj, s_HWND));
    if (PyNumber_Check(HWNDObject))
    {
      *hWnd = (ESRI_OLE_HANDLE)PyNumber_AsSsize_t(HWNDObject, 0);
      return S_OK;
    }
  }
  *hWnd = 0;
  return E_FAIL;
}

STDMETHODIMP wrap_dockablewindow::get_Name(BSTR * Name)
{
  if (m_pyObj && Name)
  {
    if (PyObject_HasAttrString(m_pyObj, s_name))
    {
      _bstr_t nameString(utils::toString(PyObject_GetAttrString(m_pyObj, s_name)));
      *Name = nameString.copy();
    }
    else
      *Name = m_id.copy();
  }

  return S_OK;
}

STDMETHODIMP wrap_dockablewindow::get_Caption(BSTR * Caption)
{
  if (m_pyObj && Caption)
  {
    if (PyObject_HasAttrString(m_pyObj, s_caption))
    {
      _bstr_t captionString(utils::toString(PyObject_GetAttrString(m_pyObj, s_caption)));
      *Caption = captionString.copy();
    }
    else if (PyObject_HasAttrString(m_pyObj, s_name))
    {
      _bstr_t captionString(utils::toString(PyObject_GetAttrString(m_pyObj, s_name)));
      *Caption = captionString.copy();
    }
    else
      *Caption = m_id.copy();
  }

  return S_OK;
}

STDMETHODIMP wrap_dockablewindow::OnDestroy()
{
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onDestroy))
    py_obj ret = PyObject_CallMethod(m_pyObj, s_onDestroy, "", NULL);

  return S_OK;
}

STDMETHODIMP wrap_dockablewindow::get_UserData(VARIANT * data )
{
  if (!data)
    return E_POINTER;

  V_VT(data) = VT_EMPTY;

  return S_OK;
}