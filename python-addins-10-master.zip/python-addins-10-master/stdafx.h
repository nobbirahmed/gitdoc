/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#ifndef STRICT
#define STRICT
#endif

#include "targetver.h"

#define _ATL_APARTMENT_THREADED
#define _ATL_NO_AUTOMATIC_NAMESPACE

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// some CString constructors will be explicit

#pragma warning (push)
#pragma warning (disable : 4192 4278) 

#define _AFXDLL
#include "afxwin.h"
// For image loading
#include <gdiplus.h>
#pragma comment( lib, "gdiplus.lib" )

#include <ESRIOLEHANDLE.h>
#include <ole2.h>

#define EXT_CLASS __declspec(dllimport) 

#include <WKSInclude.h>

#include <ImportesriDADFSystem.h>
#include <ImportesriSystem.h>
#include <ImportesriGeometry.h>
#include <ImportesriSystemUI.h>
#include <ImportesriControls.h>
#include <ImportesriSystemUtility.h>
#include <ImportesriDisplay.h>
#include <ImportesriOutput.h>
#include <ImportesriGeoDatabase.h>
#include <ImportesriDataSourcesGDB.h>
#include <ImportesriDataSourcesFile.h>
#include <ImportesriDataSourcesRaster.h>
#include <ImportesriCarto.h>
#include <ImportesriCatalog.h>
#include <ImportesriFramework.h>
#include <ImportesriGeoprocessing.h>
#include <ImportesriEditor.h>

#include <ImportesriGeoDatabaseUI.h>
#include <ImportesriArcMapUI.h>
#include <ImportesriCatalogUI.h>
#include <ImportesriGeoprocessingUI.h>

#define SearchCommand MSSearchCommand
#define IProgressDialog IMSProgressDialog
#define ISegment IMSSegment

#pragma warning (pop)

#include "resource.h"
#include <atlbase.h>
#include <atlcom.h>
#include <atlctl.h>


#include <Python.h>


using namespace esriDADFSystem;
using namespace ATL;

//inline BSTR* operator &(_bstr_t &c){ return c.GetAddress(); }
inline BSTR* at(_bstr_t &c){ return c.GetAddress(); }
