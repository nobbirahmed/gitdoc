/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once

//#include "docEvents.h"
class control;
class docEvents;
class viewEvents;

class ATL_NO_VTABLE AddInFactory :
  public CComObjectRootEx<CComSingleThreadModel>,//CComMultiThreadModelNoCS>,
  public IAddInFactory
{
public:
  AddInFactory() : m_gdiplusToken(0), m_DocEvent(NULL){};
  ~AddInFactory (){};
  DECLARE_NO_REGISTRY()

  BEGIN_COM_MAP(AddInFactory)
    COM_INTERFACE_ENTRY(IAddInFactory)
    //COM_INTERFACE_ENTRY(IMarshal)
  END_COM_MAP()
  
  STDMETHOD(Initialize)(IFactoryHook* pHook);
  STDMETHOD(CreateObject)(IAddInRecord* pRecord, IUnknown* pUnkOuter, IUnknown** ppObj);
  STDMETHOD(Shutdown)();

private:
  struct common_args
  {
    IAddInRecord* pRecord;
    IUnknown* pUnkOuter;
    IApplication* pApp;

    const char* ctrl_id;
    const char* ctrl_class_type;
    const char* ns_name;

    PyObject*   ctrl;
    PyObject*   dict;
    PyObject*   log;

    //output
    mutable control* pWrapper;
  };
  enum ctrl_type {
    eNoType,
    eButton,
    eToolbar,
    eTool,
    eMenu,
    eToolPalette,
    eComboBox,
    eDockableWindow,
    eExtension,
    eMultiItem
  };
  ULONG m_gdiplusToken;
  CComPtr<IFactoryHook> m_ipHook;
  IApplicationPtr m_ipApp;

  static PyObject* namespaceModule(LPCWSTR libName, const char* className); 
  static const char* namespaceID(const char* idName);
  enum enumCheckInstance{ eInstance, eNotExist, eWrongType};
  static enumCheckInstance checkInstance(const common_args& args);
  static PyObject* createInstance(const common_args& args);
  
  long createButton(const common_args& args, IUnknown** ppObj);
  long createToolbar(const common_args& args, IUnknown** ppObj);
  long createTool(const common_args& args, IUnknown** ppObj);
  long createMenu(const common_args& args, IUnknown** ppObj);
  long createToolPalette(const common_args& args, IUnknown** ppObj);
  long createComboBox(const common_args& args, IUnknown** ppObj);
  long createDockableWindow(const common_args& args, IUnknown** ppObj);
  long createExtension(const common_args& args, IUnknown** ppObj);
  long createMultiItem(const common_args& args, IUnknown** ppObj);

  void bind_events(control*);
  CComObject<docEvents>* m_DocEvent;
  
};
