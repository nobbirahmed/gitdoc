/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#include "StdAfx.h"
#include "constants.h"
#include "AddInFactory.h"
#include "button.h"
#include "toolbar.h"
#include "tool.h"
#include "menu.h"
#include "extension.h"
#include "dockablewindow.h"
#include "toolpalette.h"
#include "combobox.h"
#include "multiitem.h"
#include "PythonExecuteWait.h"

#include "eventsImpl.h"

#include "proxy_impls.h"

//#include <string>
//#include <fstream>
//#include <iostream>
#include <vector>

STDMETHODIMP AddInFactory::Initialize(IFactoryHook* pHook)
{  
  ATLASSERT(m_ipHook == NULL);
  m_ipHook = pHook;
  ::Py_InitializeEx(0);  
  PyImport_AddModule("__main__"); 
  register_types();

  Gdiplus::GdiplusStartupInput gdiplusStartupInput;
  Gdiplus::GdiplusStartup(&m_gdiplusToken, &gdiplusStartupInput, NULL);
  m_ipApp.CreateInstance(CLSID_AppRef);

  return S_OK;
}

const char* AddInFactory::namespaceID(const char* idName)
{
  char ns[1024] = {0};
  const char* pInst = strchr(idName, '.');
  // if '.' not in libname:
  //    namespace = libname
  if (pInst == NULL)
    pInst = idName;
  // else:
  //    namespace = libname[:libname.find('.')] + '.'
  else
  {    
    size_t n = pInst - idName;
    if (n >= sizeof(ns))
      return 0;

    strncpy(ns, idName, n);
    ns[n] = '.';
    ns[n + 1]  = 0;
    pInst = ns;
  }
  // if idname.startswith(namespace):
  if (ns[0] && strstr(idName, ns) == idName)
  {
  //    return idname[len(namespace):]
    char* newID = new char[(strlen(idName) - strlen(ns)) + 1];
    strcpy(newID, idName + strlen(ns));
    return newID;
  }
  // else:
  else
  {
  //    return idname
    char* newID = new char[strlen(idName)];
    strcpy(newID, idName);
    return newID;
  }
}

PyObject* AddInFactory::namespaceModule(LPCWSTR libName, const char* className)
{  
  char ns[1024] = {0};
  const char* pInst = strchr(className, '.');
  if (pInst == NULL)
    pInst = className;
  else
  {    
    size_t n = pInst - className;
    if (n >= sizeof(ns))
      return false;

    strncpy_s(ns, className, n);
    ns[n] = 0;
    pInst = ns;
  }
  bstr_t lname(libName);

  PyObject *pDictMain = PyModule_GetDict(PyImport_AddModule("__main__"));
  
  PyObject *pModuleNS = PyDict_GetItemString(pDictMain, ns);
  if (pModuleNS && PyModule_Check(pModuleNS))
    return pModuleNS;      

  //ATLASSERT(PyDict_SetItemString(d, proxy_app::type_name, (PyObject*)&proxy_app::pyType)==0);
  py_obj synthetic_module = PyModule_New(ns);
  ATLASSERT(!synthetic_module.isNull());

  PyModule_AddStringConstant(synthetic_module, "__file__", lname);

  PyObject* pDictLocal = PyModule_GetDict(synthetic_module);
  ATLASSERT(pDictLocal);


  PyDict_SetItemString(pDictLocal, "__builtins__", PyEval_GetBuiltins());

  PythonExecuteWait WaitHere;

  utils::dict_keys(pDictLocal);
  py_obj pyFile = PyFile_FromString((char*)(const char*)lname, "r");
  py_obj pyRet = PyRun_File(PyFile_AsFile(pyFile), (const char*)lname, Py_file_input, pDictLocal, pDictLocal);
  WaitHere.PumpError();
  utils::dict_keys(pDictLocal);

  // Add namespace module to main dict
  PyDict_SetItemString(pDictMain, ns, synthetic_module);
  utils::dict_keys(pDictMain);
  // Inject into sys.modules
  PyObject* sys_dot_modules(PySys_GetObject("modules"));
  if (sys_dot_modules && PyDict_Check(sys_dot_modules))
    PyDict_SetItemString(sys_dot_modules, ns, synthetic_module);
  
  pModuleNS = PyDict_GetItemString(pDictMain, ns);
  ATLASSERT(pModuleNS && PyModule_Check(pModuleNS));  
  return pModuleNS;
}

AddInFactory::enumCheckInstance AddInFactory::checkInstance(const common_args& args)
{
  const char *class_type_no_ns = args.ctrl_class_type + strlen(args.ns_name) + 1;
    
  PyObject *pClassType =  PyDict_GetItemString(args.dict, class_type_no_ns);
  ATLASSERT(pClassType);
  if (!pClassType)
    return eWrongType;

  PyObject *pObj = PyDict_GetItemString(args.dict, args.ctrl_id);
  if (!pObj)
    return eNotExist;
  
  switch (PyObject_IsInstance(pObj, pClassType))
  {
    case 1:  return eInstance;
    case -1:
      ATLASSERT(0); //not expected
      return eNotExist;
    default:
      return eNotExist;
  }
  //if ((((PyObject*)pObj->ob_type == (PyObject*)&PyClass_Type) || //inspect.isclass(x)
  //                  (PyObject_HasAttrString(pObj, "__bases__"))))
  //  return NULL;
  //ATLASSERT(0);  
}

PyObject* AddInFactory::createInstance(const common_args& args)
{
  char buff[128];      
  PyOS_snprintf(buff, sizeof(buff), "%s.%s=%s()", args.ns_name, args.ctrl_id, args.ctrl_class_type);
  ATLTRACE("\ncreate new %s", buff);
  PyRun_SimpleString(buff);
  if (!PyErr_Occurred())
  {
    //if we need stronger check add 'if (checkInstance(args) == eInstance)'
    //or we allow instance override it's class
    //class N : pass
    //N=N()
    return PyDict_GetItemString(args.dict, args.ctrl_id);
  }
  else
    Py_RETURN_NONE;
}

// py control class should inherit one or more abstruct event classes to resive events
// example: class button1(ButtonClass, DocumentEventsClass, ActiveViewEventsClass):
void AddInFactory::bind_events(control* pCtrl)
{  
  class helper
  {
    IFactoryHook* pFactory;
  public:
    helper(IFactoryHook *p) : pFactory(p){}
    bool createDocEvent(CComObject<docEvents>** pDocEvent)
    {
      CComPtr<IUnknown> ipUnk;
      pFactory->get_ApplicationHook(&ipUnk);
      CComQIPtr<IApplication> ipApp(ipUnk);
      CComPtr<IDocument> ipDoc;      
      if (!ipApp)
        return false;

      ipApp->get_Document(&ipDoc);
      if (!ipDoc)
        return false;
      
      if (CComObject<docEvents>::CreateInstance(pDocEvent) != S_OK)  
        return false;
      (*pDocEvent)->AddRef();
      (*pDocEvent)->connect(ipDoc);
      return true;
    }
    bool createViewEvent(IMxDocument* pDoc, CComObject<viewEvents>** pVewEvent)
    {
      CComPtr<IActiveView> ipVeiw;
      pDoc->get_ActiveView(&ipVeiw);
      if (!ipVeiw)
        return false;
      if (CComObject<viewEvents>::CreateInstance(pVewEvent) != S_OK)  
        return false;
      (*pVewEvent)->AddRef();
      (*pVewEvent)->connect(ipVeiw);
      return true;
    }
  };
}


STDMETHODIMP AddInFactory::CreateObject(IAddInRecord* pRecord, IUnknown* pUnkOuter, IUnknown** ppObj)
{
  PythonExecuteWaitNoCursor error_trapper;

  _bstr_t type;
  pRecord->get_Type(at(type));
  
  ctrl_type et = eNoType;

  if (wcscmp(type, L"Button") == 0)              et = eButton;
  else if (wcscmp(type, L"Toolbar") == 0)        et = eToolbar;
  else if (wcscmp(type, L"Tool") == 0)           et = eTool;
  else if (wcscmp(type, L"Menu") == 0)           et = eMenu;
  else if (wcscmp(type, L"ToolPalette") == 0)    et = eToolPalette;
  else if (wcscmp(type, L"ComboBox") == 0)       et = eComboBox;
  else if (wcscmp(type, L"DockableWindow") == 0) et = eDockableWindow;
  else if (wcscmp(type, L"Extension") == 0)      et = eExtension;
  else if (wcscmp(type, L"MultiItem") == 0)      et = eMultiItem;
  else 
  {    
    ATLTRACE("Unsupported control type %s", type);      
    return CLASS_E_CLASSNOTAVAILABLE;
  }
  
  common_args args;
  args.pRecord = pRecord;
  args.pUnkOuter = pUnkOuter;
  args.pApp = m_ipApp;
  args.pWrapper = NULL;
  _bstr_t library;
  
  if (FAILED(pRecord->get_Library(at(library))))
    return CLASS_E_CLASSNOTAVAILABLE;

  _bstr_t bstrID;
  if (FAILED(pRecord->ReadString(L"id", at(bstrID))))
  {
    ATLTRACE("ERROR in config.xml: type(%s) missing attribute 'id'", (const char*)type);
    return CLASS_E_CLASSNOTAVAILABLE;
  }
  args.ctrl_id = namespaceID(bstrID);

  _bstr_t cls;
  if (et != eToolbar && et != eToolPalette && et != eMenu)
  {
    if (FAILED(pRecord->get_Class(at(cls))) || cls.length() == 0)
    {
      ATLTRACE("ERROR in config.xml: id(%s) missing attribute 'id'", (const char*)bstrID);    
      return CLASS_E_CLASSNOTAVAILABLE;
    }

    PyObject* pModule = namespaceModule(library, cls);
    ATLASSERT(pModule);
    if (!pModule)
      return CLASS_E_CLASSNOTAVAILABLE;

    args.ctrl_class_type = cls;
    args.ns_name = ::PyModule_GetName(pModule); 
    args.dict = ::PyModule_GetDict(pModule);
    args.log = PyDict_GetItemString(args.dict, s_debug_log_name);
    args.ctrl = NULL;
    error_trapper.PumpError();

    enumCheckInstance eRet = checkInstance(args);
    error_trapper.PumpError();
    switch (eRet)
    {
      case eInstance:
        args.ctrl = PyDict_GetItemString(args.dict, args.ctrl_id);
        error_trapper.PumpError();
        break;

      case eNotExist:
        args.ctrl = createInstance(args);
        error_trapper.PumpError();
        break;

      case eWrongType:
        ATLTRACE("ERROR: wrong class type - %s = %s()", args.ctrl_id, args.ctrl_class_type);
        break;

      default:
        ATLASSERT(0);
        break;
    }    
    ATLASSERT(args.ctrl);
    if (!args.ctrl)
    {
      ATLTRACE("ERROR: cannot create %s = %s()", args.ctrl_id, args.ctrl_class_type);
      return CLASS_E_CLASSNOTAVAILABLE;
    }
  }
  else
  {
    //no python object
    ATLASSERT(et == eToolbar || et == eToolPalette || et == eMenu);
    args.ns_name = NULL; 
    args.dict = NULL;
    args.ctrl = NULL;
  }
  
  HRESULT hr = CLASS_E_CLASSNOTAVAILABLE;
  switch (et)
  {
    case eButton:         hr = createButton(args, ppObj);         break;
    case eToolbar:        hr = createToolbar(args, ppObj);        break;
    case eTool:           hr = createTool(args, ppObj);           break;
    case eMenu:           hr = createMenu(args, ppObj);           break;
    case eToolPalette:    hr = createToolPalette(args, ppObj);    break;
    case eComboBox:       hr = createComboBox(args, ppObj);       break;
    case eDockableWindow: hr = createDockableWindow(args, ppObj); break;
    case eExtension:      hr = createExtension(args, ppObj);      break;
    case eMultiItem:      hr = createMultiItem(args, ppObj);      break;
    default: 
      ATLASSERT(0); 
      return CLASS_E_CLASSNOTAVAILABLE;
  }

  if (hr == S_OK && args.pWrapper)
    bind_events(args.pWrapper);
  return hr;
}

STDMETHODIMP AddInFactory::Shutdown()
{
  if (m_DocEvent)
    m_DocEvent->Release();
  m_DocEvent = NULL;
  
  m_ipHook.Release();
 
  //m_ipHook = 0;
  if (m_gdiplusToken)
    Gdiplus::GdiplusShutdown(m_gdiplusToken); 
  m_gdiplusToken = 0;

  return S_OK;
}

long AddInFactory::createTool(const common_args& args, IUnknown** ppObj)
{  
  ATLASSERT(args.ctrl);  
  
  wrap_tool* tool = NULL;
  CComObject< wrap_tool >* basic_tool = NULL;
  if (CComObject<wrap_tool >::CreateInstance(&basic_tool) != S_OK)
    return E_OUTOFMEMORY;
  (*basic_tool).QueryInterface(ppObj);
  tool = static_cast<wrap_tool*>(basic_tool);

  tool->m_drawMode = drawToolAsNone;
  if (PyObject_HasAttrString(args.ctrl, "shape"))
  {
    _bstr_t shapeType(utils::toString(py_obj(PyObject_GetAttrString(args.ctrl, "shape"))));

    if (_wcsicmp(shapeType, _T("circle")) == 0)
      tool->m_drawMode = drawToolAsCircle;
    else if (_wcsicmp(shapeType, _T("line")) == 0)
      tool->m_drawMode = drawToolAsLine;
    else if (_wcsicmp(shapeType, _T("rect")) == 0 ||
             _wcsicmp(shapeType, _T("rectangle")) == 0)
      tool->m_drawMode = drawToolAsRectangle;
  }
  else
  {
    if (PyObject_HasAttrString(args.ctrl, s_onCircle))
      tool->m_drawMode = drawToolAsCircle;
    else if (PyObject_HasAttrString(args.ctrl, s_onLine))
      tool->m_drawMode = drawToolAsLine;
    else if (PyObject_HasAttrString(args.ctrl, s_onRectangle))
      tool->m_drawMode = drawToolAsRectangle;
  }
  
  ATLASSERT(tool);

  tool->initControl(args.ctrl_id, args.ctrl, args.dict);  
  tool->readConfig(args.pRecord);

  return S_OK;
}

long AddInFactory::createToolbar(const common_args& args, IUnknown** ppObj)
{
  ATLASSERT(args.ctrl == NULL);

  CComObject<wrap_toolbar>* tb = NULL;
  if (CComObject<wrap_toolbar>::CreateInstance(&tb) != S_OK)
    return E_OUTOFMEMORY;

  tb->m_id = args.ctrl_id;
  args.pRecord->ReadString(L"caption", at(tb->m_caption));

  IEnumNodePtr ipEnumNode;  
  if (args.pRecord->GetList(L"Items", &ipEnumNode) == S_OK)
  {
    IXMLNodePtr ipNode;

    while (ipEnumNode->Next(&ipNode) == S_OK)
    {
      wrap_toolbar::def item;
      bstr_t recordVal;
      if (ipNode->ReadString(L"refID", at(recordVal)) != S_OK)
      {
        ATLTRACE(L"ERROR in config.xml: <Toolbar><Items> missing attribute 'refID'");
        continue;
      }

      GUID guid;
      bool hasSeparator = false;

      if (m_ipHook->TranslateID(recordVal, &guid) == S_OK)
      {
        VARIANT_BOOL sep;
        if (ipNode->ReadBool(L"separator", &sep) == S_OK)
        {
          if (sep == VARIANT_TRUE)
            hasSeparator = true;
        }

        wchar_t buf[64];
        ::StringFromGUID2(guid, buf, 64);
        
        item.id = buf;
        item.sub = 0;
        item.group = hasSeparator;

        ipNode->ReadInteger(L"subtype", &item.sub);

        tb->m_items.push_back(item);
      }
    }
  }
    
  return (*tb).QueryInterface(ppObj);
}

long AddInFactory::createButton(const common_args& args, IUnknown** ppObj)
{
  ATLASSERT(args.ctrl);
    
  CComObject<wrap_button> *btn = NULL;
  if (CComObject<wrap_button>::CreateInstance(&btn) != S_OK)
    return E_OUTOFMEMORY;

  btn->initControl(args.ctrl_id, args.ctrl, args.dict);  
  btn->readConfig(args.pRecord);
  args.pWrapper = btn;

  return (*btn).QueryInterface(ppObj);
}

long AddInFactory::createMenu(const common_args& args, IUnknown** ppObj)
{
  CComObject<wrap_menu>* menu = NULL;
  if (CComObject<wrap_menu>::CreateInstance(&menu) != S_OK)
    return E_OUTOFMEMORY;

  IEnumNodePtr ipEnumNode;  
  if (args.pRecord->GetList(L"Items", &ipEnumNode) == S_OK)
  {
    IXMLNodePtr ipNode;

    while (ipEnumNode->Next(&ipNode) == S_OK)
    {
      wrap_menu::def item;
      bstr_t recordVal;
      if (ipNode->ReadString(L"refID", at(recordVal)) != S_OK)
      {
        ATLTRACE(L"ERROR in config.xml: <Toolbar><Items> missing attribute 'refID'");
        continue;
      }

      GUID guid;
      bool hasSeparator = false;

      if (m_ipHook->TranslateID(recordVal, &guid) == S_OK)
      {
        VARIANT_BOOL sep;
        if (ipNode->ReadBool(L"separator", &sep) == S_OK)
        {
          if (sep == VARIANT_TRUE)
            hasSeparator = true;
        }

        wchar_t buf[64];
        ::StringFromGUID2(guid, buf, 64);
        
        item.id = buf;
        item.sub = 0;
        item.group = hasSeparator;

        ipNode->ReadInteger(L"subtype", &item.sub);

        menu->m_items.push_back(item);
      }
    }
  }

  menu->m_id = args.ctrl_id;
  menu->readConfig(args.pRecord);
  //args.pWrapper = menu;

  return (*menu).QueryInterface(ppObj);
}

long AddInFactory::createToolPalette(const common_args& args, IUnknown** ppObj)
{
  PyObject* ctrl;
  ctrl = args.ctrl;
  if (!ctrl)
  {
    ctrl = Py_None;
    Py_INCREF(ctrl);
  }

  ATLASSERT(ctrl);
  CComObject<wrap_toolpalette>* toolpalette = NULL;
  if (CComObject<wrap_toolpalette>::CreateInstance(&toolpalette) != S_OK)
    return E_OUTOFMEMORY;
  toolpalette->initControl(args.ctrl_id, ctrl, args.dict);
  toolpalette->readConfig(args.pRecord);
  
  long columncount = 2;
  if (SUCCEEDED(args.pRecord->ReadInteger(L"columns", &columncount)))
    toolpalette->m_columncount = columncount;
  VARIANT_BOOL tearoff = VARIANT_TRUE;
  if (SUCCEEDED(args.pRecord->ReadBool(L"canTearOff", &tearoff)))
    toolpalette->m_cantearoff = (tearoff == VARIANT_TRUE) ? true : false;
  VARIANT_BOOL menustyle = VARIANT_FALSE;
  if (SUCCEEDED(args.pRecord->ReadBool(L"isMenuStyle", &menustyle)))
    toolpalette->m_ismenustyle = (menustyle == VARIANT_TRUE) ? true : false;

  IEnumNodePtr ipEnumNode;  
  if (args.pRecord->GetList(L"Items", &ipEnumNode) == S_OK)
  {
    IXMLNodePtr ipNode;

    while (ipEnumNode->Next(&ipNode) == S_OK)
    {
      wrap_toolbar::def item;
      bstr_t recordVal;
      if (ipNode->ReadString(L"refID", at(recordVal)) != S_OK)
      {
        ATLTRACE(L"ERROR in config.xml: <ToolPalette><Items> missing attribute 'refID'");
        continue;
      }

      GUID guid;
      bool hasSeparator = false;

      if (m_ipHook->TranslateID(recordVal, &guid) == S_OK)
      {
        wchar_t buf[64];
        ::StringFromGUID2(guid, buf, 64);

        toolpalette->m_items.push_back(bstr_t(buf));
      }
    }
  }
  return (*toolpalette).QueryInterface(ppObj);
}

long AddInFactory::createComboBox(const common_args& args, IUnknown** ppObj)
{
  ATLASSERT(args.ctrl);

  CComObject<wrap_combobox>* combobox = NULL;
  if (CComObject<wrap_combobox>::CreateInstance(&combobox) != S_OK)
    return E_OUTOFMEMORY;

  combobox->initControl(args.ctrl_id, args.ctrl, args.dict);
  combobox->readConfig(args.pRecord);
  args.pWrapper = combobox;
  return (*combobox).QueryInterface(ppObj);
}

long AddInFactory::createDockableWindow(const common_args& args, IUnknown** ppObj)
{
  ATLASSERT(args.ctrl);

  CComObject<wrap_dockablewindow>* dockwindow = NULL;
  if (CComObject<wrap_dockablewindow>::CreateInstance(&dockwindow) != S_OK)
    return E_OUTOFMEMORY;

  dockwindow->initControl(args.ctrl_id, args.ctrl, args.dict);
  return (*dockwindow).QueryInterface(ppObj);
}

long AddInFactory::createExtension(const common_args& args, IUnknown** ppObj)
{
  ATLASSERT(args.ctrl);

  CComObject<wrap_extension>* extn = NULL;
  if (CComObject<wrap_extension>::CreateInstance(&extn) != S_OK)
    return E_OUTOFMEMORY;

  VARIANT_BOOL auto_load(VARIANT_FALSE);

  extn->setPy(args.ctrl);
  extn->m_id = args.ctrl_id;
  extn->m_ipApp = args.pApp;
  IExtensionPtr ipExt;
  IUIDAdminPtr ipUID(CLSID_UID);
  ipUID->SetID((GUID*)&CLSID_Editor, 0);
  extn->m_ipApp->FindExtensionByCLSID((IUIDPtr)ipUID, &ipExt);
  (extn->m_ipEditor) = ipExt;
  if (extn->m_ipApp)
    extn->m_ipApp->AddRef();
  args.pRecord->ReadString(L"name", at(extn->m_name));
  args.pRecord->ReadString(L"description", at(extn->m_description));
  args.pRecord->ReadBool(L"autoLoad", &auto_load);
  args.pRecord->ReadBool(L"showInExtensionDialog", &extn->m_showInDialog);
  if (args.ctrl)
    PyObject_SetAttrString(args.ctrl, s_enabled, auto_load ? Py_True : Py_False);
  return (*extn).QueryInterface(ppObj);
}

long AddInFactory::createMultiItem(const common_args& args, IUnknown** ppObj)
{
  ATLASSERT(args.ctrl);

  CComObject<wrap_multiitem>* multitem = NULL;
  if (CComObject<wrap_multiitem>::CreateInstance(&multitem) != S_OK)
    return E_OUTOFMEMORY;

  multitem->initControl(args.ctrl_id, args.ctrl, args.dict);
  return (*multitem).QueryInterface(ppObj);
}