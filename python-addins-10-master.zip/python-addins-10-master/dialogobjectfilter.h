/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#include "stdafx.h"
#include "PythonExecuteWait.h"

class ATL_NO_VTABLE DialogObjectFilter :
	public CComObjectRootEx<CComSingleThreadModel>,
  public IGxObjectFilter
{

  py_obj m_filterCallable;
  _bstr_t m_Label;

public:
  void init(PyObject* pFilterCallable, _bstr_t label)
  {
    Py_XINCREF(pFilterCallable);
    m_filterCallable = pFilterCallable;
    m_Label = label.copy();
  }

    // IGxObjectFilter Methods
  STDMETHOD(get_Name)(BSTR * Name)
  {
    if (Name)
    {
      *Name = m_Label.copy();
    }
    else
    {
      return E_POINTER;
    }
    return S_OK;
  };
  STDMETHOD(get_Description)(BSTR * Description)
  {
    return get_Name(Description);
  };
  STDMETHOD(CanDisplayObject)(IGxObject * pObject, VARIANT_BOOL * canDisplay)
  {
    if (canDisplay)
      *canDisplay = VARIANT_TRUE;
    else
      return E_POINTER;
    return S_OK;
  };
  STDMETHOD(CanChooseObject)(IGxObject * pObject, enum esriDoubleClickResult * result, VARIANT_BOOL * canChoose)
  {
    _bstr_t objectPath;
    if (pObject)
    {
      pObject->get_FullName(at(objectPath));
    }

    if (result)
    {
      if (IGxObjectContainerPtr(pObject))
      {
        *result = esriDCRShowChildren;
      }
      else
      {
        *result = esriDCRDefault;
      }
    }

    PythonExecuteWaitNoCursor wait;

    py_obj itemPath(PyUnicode_FromWideChar(objectPath, (Py_ssize_t)::SysStringLen(objectPath))),
           args(Py_BuildValue("(O)", (PyObject*)itemPath)),
           callFunctionResult(PyObject_Call(m_filterCallable, args, NULL));

    wait.PumpError();

    if (canChoose)
    {
      *canChoose = (callFunctionResult && PyObject_IsTrue(callFunctionResult)) ? VARIANT_TRUE: VARIANT_FALSE;
      if (result && !canChoose)
      {
        *result = esriDCRNothing;
      }
    }

    PyErr_Clear();

    return S_OK;
  };
  STDMETHOD(CanSaveObject)(IGxObject * pLocation, BSTR newObjectName, VARIANT_BOOL * objectAlreadyExists, VARIANT_BOOL * canSave)
  {
    _bstr_t locationPath;
    if (pLocation)
      pLocation->get_FullName(at(locationPath));
    if (locationPath.length())
      locationPath += L"\\";
    locationPath += newObjectName;

    if (objectAlreadyExists)
      *objectAlreadyExists = VARIANT_FALSE;

    py_obj locationPathObject(PyUnicode_FromWideChar(locationPath, (Py_ssize_t)::SysStringLen(locationPath))),
           callFunctionResult(PyObject_CallFunction(m_filterCallable, "O", (PyObject*)locationPathObject));

    if (canSave)
      *canSave = PyObject_IsTrue(callFunctionResult) ? VARIANT_TRUE: VARIANT_FALSE;

    PyErr_Clear();

    return S_OK;
  };

  BEGIN_COM_MAP(DialogObjectFilter)
	  COM_INTERFACE_ENTRY(IGxObjectFilter)
  END_COM_MAP()
};