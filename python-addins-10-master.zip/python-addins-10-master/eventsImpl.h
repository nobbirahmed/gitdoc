/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once
#include "utils.h"
#include "constants.h"

template<class I, const GUID& clsid>
class ATL_NO_VTABLE event_impl: public event_base,
  public CComObjectRootEx<CComSingleThreadModel>,
  public I
{
public:
  BEGIN_COM_MAP(event_impl)
	  COM_INTERFACE_ENTRY(I)
  END_COM_MAP()

  void FinalRelease()
  {
    ATLASSERT(m_binds.empty()); //must be empty    
    ATLASSERT(m_ipSource == NULL);
    ATLASSERT(m_ipEventHelper == NULL);
  }

  long connect(IUnknown* pSource)
  {
    ATLASSERT(m_ipSource == NULL && pSource != NULL);        
    HRESULT hr = S_OK;
    if (!m_ipEventHelper)
      hr = m_ipEventHelper.CoCreateInstance(clsid);

    ATLASSERT(m_ipEventHelper);

    if (hr == S_OK && m_ipEventHelper)
    {
      m_ipSource = pSource;      
      hr = m_ipEventHelper->Advise(static_cast<I*>(this), (GUID*)&__uuidof(I), m_ipSource);
      if (hr != S_OK)
      {
        m_ipEventHelper.Release();
        m_ipSource.Release();
      }
    }
    return hr;
  }
};
/////////////////////

class ATL_NO_VTABLE viewEvents : public event_impl<IActiveViewEvents, CLSID_ActiveViewEventsHelper>
{
public:
  

  //IActiveViewEvents
  STDMETHOD(ContentsChanged)()
  {
    forward_call0(m_binds, s_contentsChanged);
    return S_OK;
  }
  STDMETHOD(ContentsCleared)()
  {
    forward_call0(m_binds, s_contentsCleared);
    return S_OK;
  }
  STDMETHOD(ItemAdded)(VARIANT Item)
  {
    //forward_call0(m_binds, );
    return S_OK;
  }  
  STDMETHOD(ItemDeleted)(VARIANT Item)
  {
    //forward_call0(m_binds, );
    return S_OK;
  }

  STDMETHOD(ItemReordered)(VARIANT Item, long toIndex)
  {
    //forward_call0(m_binds, );
    return S_OK;
  }

  STDMETHOD(SelectionChanged)()
  {
    forward_call0(m_binds, s_selectionChanged);
    return S_OK;
  }

  STDMETHOD(ViewRefreshed)(IActiveView * view, esriViewDrawPhase phase, VARIANT Data, IEnvelope * envelope)
  {
    //forward_call0(m_binds, );
    return S_OK;
  }

  STDMETHOD(AfterDraw)(IDisplay * Display, esriViewDrawPhase phase)
  {
    //forward_call0(m_binds, );
    return S_OK;
  }

  STDMETHOD(AfterItemDraw)(short Index, IDisplay * Display, esriDrawPhase phase)
  {
    //forward_call0(m_binds, );
    return S_OK;
  }

  STDMETHOD(FocusMapChanged)()
  {
    forward_call0(m_binds, s_focusMapChanged);
    return S_OK;
  }

  STDMETHOD(SpatialReferenceChanged)()
  {
    forward_call0(m_binds, s_spatialReferenceChanged);
    return S_OK;
  }
};

class ATL_NO_VTABLE docEvents : public event_impl<IDocumentEvents, CLSID_DocumentEventsHelper>
{
public:
  //ActiveViewEvent need reconnect in NewDoc
  CComObject<viewEvents>* m_ActiveViewEvent;
  docEvents() : m_ActiveViewEvent(NULL){}
  ~docEvents()
  {
    if (m_ActiveViewEvent)
      m_ActiveViewEvent->Release();
  }
  //IDocumentEvents
  STDMETHOD(ActiveViewChanged)()
  {
    PythonExecuteWaitNoCursor WaitHere;

    //do we need reconnect m_ActiveViewEvent?
    forward_call0(m_binds, s_activeViewChanged);
    return S_OK;
  }
  STDMETHOD(MapsChanged)()
  {
    PythonExecuteWaitNoCursor WaitHere;

    forward_call0(m_binds, s_mapsChanged);
    return S_OK;
  }
  STDMETHOD(OnContextMenu) (long x, long y, VARIANT_BOOL* handled)
  {
    //TODO
    return S_OK;
  }
  STDMETHOD(NewDocument)()
  {
    if (m_ActiveViewEvent) //reconnect
    {
      CComQIPtr<IMxDocument> m_ipMxDoc(m_ipSource);
      CComPtr<IActiveView> ipView;
      m_ipMxDoc->get_ActiveView(&ipView);
      if (ipView && m_ActiveViewEvent->m_ipSource != ipView)
        m_ActiveViewEvent->connect(ipView);
    }

    PythonExecuteWaitNoCursor WaitHere;

    forward_call0(m_binds, s_newDocument);
    return S_OK;
  }
  STDMETHOD(OpenDocument)()
  {
    forward_call0(m_binds, s_openDocument);
    return S_OK;
  }
  STDMETHOD(BeforeCloseDocument)(VARIANT_BOOL* abortClose)
  {    
    PythonExecuteWaitNoCursor WaitHere;
    list_type::const_iterator it = m_binds.begin();
    while (it != m_binds.end())
    {      
      py_obj ret = utils::call_member0(const_cast<PyObject*>(*it), s_beforeCloseDocument);
      if (!ret.isNull() && PyBool_Check(ret))
      {
         if (ret == Py_True)
         {
           *abortClose = VARIANT_TRUE;
           break;
         }
      }
      ++it;
      WaitHere.PumpError();
    }

    return S_OK;
  }
  STDMETHOD(CloseDocument)()
  {
    if (m_ActiveViewEvent)
      m_ActiveViewEvent->disconnect();

    PythonExecuteWaitNoCursor WaitHere;

    forward_call0(m_binds, s_closeDocument);
    return S_OK;
  }  
};

