/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once

template <size_t _size>
inline int strcmp_s(const char(&_s1)[_size], const char* _s2){ return strncmp(_s1, _s2, _size); }


#define BEGIN_CALL_MAP(x) public:\
  PyObject* processCall(const char* name_, PyObject *args, bool& h) \
	{

#define END_CALL_MAP() {h = false;} \
  return PyErr_Format(PyExc_AttributeError, "Invalid attribute %s", name_); }



#define BEGIN_ATTR_MAP(x) public:\
  PyObject* processAttr(const char* name_, PyObject* in, bool& h) \
	{

#define END_ATTR_MAP() {h = false;} \
    return NULL; \
  }

#define CALL_HANDLER(n_, func_) \
  if (strcmp_s(#n_, name_) == 0) { h = true; return func_(args); } else

#define CALL_DIRECT_VOID_(n_, m_) \
  if (strcmp_s((#n_), name_) == 0) { h = true; \
    HRESULT hr = m_pHook->##m_();\
    if (hr == S_OK) Py_RETURN_NONE; else  return NULL;\
  } else
#define CALL_DIRECT_VOID(n_) CALL_DIRECT_VOID_(n, n_)

#define CALL_DIRECT_QI_VOID_(n_, m_, qi_) \
  if (strcmp_s((#n_), name_) == 0) { h = true; \
    HRESULT hr = ##qi_##Ptr(m_pHook)->##m_();\
    if (hr == S_OK) Py_RETURN_TRUE; else  Py_RETURN_FALSE;\
  } else
#define CALL_DIRECT_QI_VOID(n_, qi_) CALL_DIRECT_QI_VOID_(n_, n_, qi_) 

#define CALL_DIRECT_1STR(n_, func_) \
  if (strcmp_s((#n_), name_) == 0) { h = true; return func_(utils::toString(PyTuple_GET_ITEM(args, 0))); } else




#define GET_HANDLER(n_, func_) \
  if (in == NULL && strcmp_s((#n_), name_) == 0) { h = true; return func_(); } else

#define SET_HANDLER(n_, func_) \
  if (in != NULL && strcmp_s((#n_), name_) == 0) { h = true; func_(in); Py_RETURN_NONE;} else

#define GET_SET_HANDLER(n_, func_) \
  if (strcmp_s((#n_), name_) == 0) { h = true; return func_(in); } else

#define _GET_DIRECT_LONG_(m_) \
  { h = true; \
    long ret = 0; HRESULT hr = m_pHook->get_##m_(&ret);\
    return PyLong_FromLong(ret);\
  } 

#define GET_DIRECT_LONG_(n_,m_) if (in == NULL && strcmp_s((#n_), name_) == 0) _GET_DIRECT_LONG_(m_) else
#define GET_DIRECT_LONG(n_) GET_DIRECT_LONG_(n_, n_)


#define _GET_DIRECT_DOUBLE_(m_)          \
  { h = true; double ret = 0;            \
    HRESULT hr = m_pHook->get_##m_(&ret);\
    return PyFloat_FromDouble(ret);      \
  }

#define GET_DIRECT_DOUBLE_(n_,m_) if (in == NULL && strcmp_s((#n_), name_) == 0) _GET_DIRECT_DOUBLE_(m_) else

#define GET_DIRECT_DOUBLE(n_) GET_DIRECT_DOUBLE_(n_, n_)

#define _SET_DIRECT_DOUBLE_(m_, o_) \
  { h = true;                       \
    if (PyFloat_Check(o_))          \
    { HRESULT hr = m_pHook->put_##m_(PyFloat_AS_DOUBLE(o_));\
      Py_RETURN_NONE;               \
    }                               \
    return NULL;                    \
  }

#define GET_SET_DIRECT_DOUBLE(n_) \
  if (strcmp_s((#n_), name_) == 0) {\
     if (in == NULL) _GET_DIRECT_DOUBLE_(n_) else _SET_DIRECT_DOUBLE_(n_, in)\
  }else


#define _GET_DIRECT_BSTR_(m_){ h = true; \
    bstr_t ret; HRESULT hr = m_pHook->get_##m_(ret.GetAddress());\
    return PyUnicode_FromWideChar(ret, ret.length()); \
    }

#define _SET_DIRECT_BSTR_(m_, v_){ h = true; \
    bstr_t bstr = utils::toString(v_);   \
    if (utils::if_error())               \
       return NULL;                      \
    HRESULT hr = m_pHook->put_##m_(bstr);\
    Py_RETURN_NONE;                      \
  }else

#define GET_DIRECT_BSTR(n_) if (strcmp_s((#n_), name_) == 0) _GET_DIRECT_BSTR_(n_) else


#define SET_DIRECT_BSTR(n_, v_) _SET_DIRECT_BSTR_(n_, v)

#define GET_SET_DIRECT_BSTR(n_) \
  if (strcmp_s((#n_), name_) == 0) {\
     if (in == NULL) _GET_DIRECT_BSTR_(n_) else _SET_DIRECT_BSTR_(n_, in)\
  }else

#define GET_SET_DIRECT_BOOL_(n_, m_)              \
  if (strcmp_s((#n_), name_) == 0)                \
  { h = true;                                     \
    if (in == NULL)                               \
    { VARIANT_BOOL ret = VARIANT_FALSE;           \
      HRESULT hr = m_pHook->get_##m_(&ret);       \
      if (ret != VARIANT_FALSE)                   \
        Py_RETURN_TRUE;                           \
      Py_RETURN_FALSE;                            \
    }                                             \
    if (PyBool_Check(in))                         \
    {  m_pHook->put_##m_((in != Py_False) ? VARIANT_TRUE : VARIANT_FALSE);\
       Py_RETURN_NONE;                            \
    }                                             \
    return NULL;                                  \
  } else

#define GET_SET_DIRECT_BOOL(n_) GET_SET_DIRECT_BOOL_(n_, n_) 
