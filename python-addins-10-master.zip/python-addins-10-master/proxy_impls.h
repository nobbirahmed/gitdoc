/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once
#include "proxy.h"
#include "proxy_defs.h"

void register_types();


class proxy_app: public proxy<proxy_app, IApplication>
{
public:

  BEGIN_ATTR_MAP(proxy_app)
    GET_HANDLER(Doc, getDoc) 
  END_ATTR_MAP()

  BEGIN_CALL_MAP(proxy_app)
    //CALL_HANDLER(NewDocument, newDocument)
    CALL_DIRECT_1STR(NewDocument, newDocument)
  END_CALL_MAP()
protected:
  PyObject* getDoc();
  PyObject* newDocument(const bstr_t &str);
};

class proxy_doc: public proxy<proxy_doc, IDocument>
{
public:

  BEGIN_ATTR_MAP(proxy_doc) 
    //GET_HANDLER(Title, getTitle)
    GET_DIRECT_BSTR(Title)
    GET_HANDLER(FocusMap, getMap)
  END_ATTR_MAP()

  BEGIN_CALL_MAP(proxy_doc)
    CALL_DIRECT_QI_VOID(UpdateContents, IMxDocument)
  END_CALL_MAP()
protected:
  PyObject* getTitle();
  PyObject* getMap();
};

class proxy_map: public proxy<proxy_map, IMap>
{
public:

  BEGIN_ATTR_MAP(proxy_map) 
    GET_SET_HANDLER(Name, attrName)
    GET_DIRECT_LONG(LayerCount)
    GET_HANDLER(Layers, getLayers) 
  END_ATTR_MAP()

  BEGIN_CALL_MAP(proxy_map)    
    CALL_HANDLER(Layer, getLayer)     
  END_CALL_MAP()
protected:  
  PyObject* attrName(PyObject* in);
  PyObject* getLayer(PyObject* in);
  PyObject* getLayers();
};

class proxy_layer: public proxy<proxy_layer, ILayer>
{
public:

  BEGIN_ATTR_MAP(proxy_layer) 
    GET_SET_HANDLER(Name, attrName)
    GET_SET_DIRECT_BOOL(Visible)
  END_ATTR_MAP()

  BEGIN_CALL_MAP(proxy_layer)
  END_CALL_MAP()
protected:  
  PyObject* attrName(PyObject* in);
};
