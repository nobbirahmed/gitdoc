/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#include "stdafx.h"
#include "constants.h"
#include "combobox.h"

typedef struct ComboBoxRefreshObject
{
    PyObject_HEAD
    wrap_combobox* pComboBox;
    PyObject* pSelf;
} ComboBoxRefreshObject;

static void ComboBoxRefreshObject_dealloc(ComboBoxRefreshObject *self)
{
  if (self->pSelf)
    Py_DECREF(self->pSelf);
  PyObject_DEL(self);
}

static PyObject* ComboBoxRefreshObject_call(ComboBoxRefreshObject *self, PyObject *args, PyObject* kws)
{
  PyObject *pSelfObject(0),
           *return_value(0);
  if (self->pSelf)
  {
    PyErr_Clear();
    pSelfObject = PyWeakref_GetObject(self->pSelf);
    if (pSelfObject != Py_None && PyObject_HasAttrString(pSelfObject, "_refresh"))
      return_value = PyObject_CallMethod(pSelfObject, "_refresh", 0);
    else
    {
      return_value = Py_None;
      Py_INCREF(Py_None);
    }
  }

  if (self->pComboBox && !(PyErr_Occurred()))
    self->pComboBox->UpdateItems(true);

  if (pSelfObject && pSelfObject != Py_None)
    return return_value;
  else
    Py_RETURN_NONE;
}

static PyTypeObject ComboBoxRefreshObject_Type = {
    PyObject_HEAD_INIT(&PyType_Type)
    0,                                        /*ob_size*/
    "Wrapped combobox.refresh object",        /*tp_name*/
    sizeof(ComboBoxRefreshObject),            /*tp_basicsize*/
    0,                                        /*tp_itemsize*/
    (destructor)ComboBoxRefreshObject_dealloc,/*tp_dealloc*/
    0,                                        /*tp_print*/
    0,                                        /*tp_getattr*/
    0,                                        /*tp_setattr*/
    0,                                        /*tp_compare*/
    0,                                        /*tp_repr*/
    0,                                        /*tp_as_number*/
	  0,                                	      /*tp_as_sequence*/
	  0,                                		    /*tp_as_mapping*/
	  0,                                        /*tp_hash*/
	  (ternaryfunc)ComboBoxRefreshObject_call,  /*tp_call*/
	  0,     			                              /*tp_str*/
	  0,		     	                              /*tp_getattro*/
	  0,			                                  /*tp_setattro*/
	  0,		                               	    /*tp_as_buffer*/
	  Py_TPFLAGS_DEFAULT,                  	    /*tp_flags*/
};

void wrap_combobox::UpdateItems(bool force)
{
  if (m_ipHook && m_pyObj)
  {
    bool has_value(PyObject_HasAttrString(m_pyObj, s_value) != 0);
    if (PyObject_HasAttrString(m_pyObj, s_items) ||
        has_value)
    {
      py_obj items(PyObject_GetAttrString(m_pyObj, s_items));
      py_obj pyval(has_value ? PyObject_GetAttrString(m_pyObj, s_value) : 0);
      _bstr_t py_value(utils::toString(pyval)),
              value;
      m_ipHook->get_Value(at(value));

      if (!m_cachedItems || (PyObject_Compare(m_cachedItems, items) != 0) ||
          (has_value && (py_value != value)) || force)
      {
        if (PySequence_Check(items))
        {
          m_ipHook->Clear();
          m_cookies.clear();
          Py_ssize_t sequence_length = PySequence_Length(items);
          m_rowCount = sequence_length;
          for (Py_ssize_t index = 0; index < sequence_length; ++index)
          {
            long cookie;
            py_obj item = PySequence_GetItem(items, index);
            m_ipHook->Add(utils::toString(item), &cookie);
            m_cookies.insert(std::pair<long, py_obj>(cookie, item));
          }
          PyErr_Clear();
          m_cachedItems = PySequence_GetSlice(items, 0, PySequence_Length(items));
        }
        if (has_value && (py_value != value))
          value = py_value;

        m_ipHook->put_Value(value);
      }
    }
  }
}

STDMETHODIMP wrap_combobox::OnCreate(IDispatch* pHook)
{
  m_ipHook = pHook;

  ComboBoxRefreshObject* RefreshWrapper = PyObject_New(ComboBoxRefreshObject, (PyTypeObject*)&ComboBoxRefreshObject_Type);

  RefreshWrapper->pComboBox = this;
  //pComboBox->AddRef();  // Can't own ref; introduces a circular reference

  py_obj refresh_method(PyObject_GetAttrString(m_pyObj, "refresh"));
  PyErr_Clear();

  RefreshWrapper->pSelf = PyWeakref_NewRef((PyObject*)m_pyObj, 0);

  if (refresh_method)
    PyObject_SetAttrString((PyObject*)m_pyObj, "_refresh", (PyObject*)refresh_method);

  PyObject_SetAttrString(m_pyObj, "refresh", (PyObject*)RefreshWrapper);
  Py_DECREF(RefreshWrapper);

  if (!PyObject_HasAttrString((PyObject*)m_pyObj, "items"))
  {
    py_obj item_object(PyList_New(0));
    PyObject_SetAttrString((PyObject*)m_pyObj, "items", (PyObject*)item_object);
  }

  UpdateItems();
  return S_OK;
}

STDMETHODIMP wrap_combobox::get_Editable(VARIANT_BOOL * Editable)
{
  bool editable = true;
  utils::attr(m_pyObj, s_editable, editable);
  *Editable = (editable) ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

STDMETHODIMP wrap_combobox::get_Width(BSTR * stringForWidth)
{
  bstr_t stringforwidth = "WWWWWW";
  utils::attr(m_pyObj, s_width, stringforwidth);
  *stringForWidth = stringforwidth.copy();
  return S_OK;
}

STDMETHODIMP wrap_combobox::get_DropDownWidth(BSTR * stringForWidth)
{
  bstr_t stringforwidth = "WWWWWW";
  utils::attr(m_pyObj, s_dropdownwidth, stringforwidth);
  *stringForWidth = stringforwidth.copy();
  return S_OK;
}

STDMETHODIMP wrap_combobox::get_DropDownHeight(long * rowsHigh)
{
  long rowshigh = m_rowCount;
  utils::attr(m_pyObj, s_height, rowshigh);
  *rowsHigh = rowshigh;
  return S_OK;
}

STDMETHODIMP wrap_combobox::get_HintText(BSTR * HintText)
{
  utils::attr(m_pyObj, s_hinttext, m_hinttext);
  *HintText = m_hinttext.copy();
  return S_OK;
}

STDMETHODIMP wrap_combobox::OnSelChange(long cookie)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onSelChange))
  {
    PythonExecuteWait RunWrap;

    py_obj edittext = m_cookies[cookie];
    if (!edittext)
    {
      edittext = PyUnicode_FromWideChar(L"", 0);
    }
    PyObject_SetAttrString(m_pyObj, s_value, edittext);
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onSelChange, "O", (PyObject*)edittext);
    if (!PyErr_Occurred())
    {
      _bstr_t value_string(utils::toString(edittext));
      m_ipHook->put_Value(value_string);
    }
  }
  UpdateItems();
  return S_OK;
}

STDMETHODIMP wrap_combobox::OnEditChange(BSTR editString)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onEditChange))
  {
    PythonExecuteWait RunWrap;

    py_obj edittext = PyUnicode_FromWideChar(editString, ::SysStringLen(editString));
    PyObject_SetAttrString(m_pyObj, "value", edittext);
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onEditChange, "O", edittext ? edittext : Py_None);
  }

  //UpdateItems();
  return S_OK;
}

STDMETHODIMP wrap_combobox::OnFocus(VARIANT_BOOL set)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

 if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onFocus))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_onFocus, "O", (set == VARIANT_TRUE) ? Py_True : Py_False);
  }
  UpdateItems();
  return S_OK;
}

STDMETHODIMP wrap_combobox::OnEnter()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onEnter))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_onEnter, NULL);
  }
  //UpdateItems();
  return S_OK;
}

STDMETHODIMP wrap_combobox::get_ShowCaption(VARIANT_BOOL * ShowCaption)
{
  *ShowCaption = (m_caption.length()) ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}