/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#include "stdafx.h"
#include "utils.h"
#include <vector>
#include "Python.h"
#include "PythonAddinFunctions.h"
#include "dialogobjectfilter.h"

namespace addinfunctions
{

static void SetupDialog(IGxDialog* pDialog, PyObject* title, PyObject* multiple_selection, 
                        PyObject* name_text, PyObject* starting_location, PyObject* button_caption,
                        PyObject* filter_function, PyObject* filter_label)
{
  if (PyObject_IsTrue(title))
    pDialog->put_Title(utils::toString(title));

  pDialog->put_AllowMultiSelect(PyObject_IsTrue(multiple_selection) ? VARIANT_TRUE : VARIANT_FALSE);

  if (PyObject_IsTrue(starting_location))
  {
    variant_t starting_location_vt;
    ::VariantInit(&starting_location_vt);
    _bstr_t location_string(utils::toString(starting_location));

    starting_location_vt.vt = VT_BSTR;
    starting_location_vt.bstrVal = location_string.Detach();
    pDialog->put_StartingLocation(&starting_location_vt);

    ::VariantClear(&starting_location_vt);
  }

  if (name_text && PyObject_IsTrue(name_text))
  {
    pDialog->put_Name(utils::toString(name_text));
  }

  if (button_caption && PyObject_IsTrue(button_caption))
  {
    pDialog->put_ButtonCaption(utils::toString(button_caption));
  }

  if (filter_function && PyObject_IsTrue(filter_function) && PyCallable_Check(filter_function))
  {
    _bstr_t filter_caption(utils::toString(filter_function));
    if (filter_label && filter_label != Py_None)
    {
      filter_caption = utils::toString(filter_label);
    }
    CComObject<DialogObjectFilter> *filter = NULL;
    if (CComObject<DialogObjectFilter>::CreateInstance(&filter) == S_OK)
    {
      filter->init(filter_function, filter_caption);
      pDialog->putref_ObjectFilter(IGxObjectFilterPtr(filter));
    }
  }
}

PyObject* OpenDialog(PyObject* self, PyObject* args, PyObject* kws)
{
  static char *kwlist[] = {"title", "multiple_selection", "starting_location", "button_caption", "filter", "filter_label", NULL};

  IApplicationPtr ipApp;
  HRESULT hr = ipApp.CreateInstance(CLSID_AppRef);

  if(FAILED(hr) || !ipApp)
  {
    PyErr_SetString(PyExc_RuntimeError, "Not running in a desktop application.");
    return 0;
  }

  PyObject *title(Py_None),
           *multiple_selection(Py_None),
           *starting_location(Py_None),
           *button_caption(Py_None),
           *filter_object(0),
           *filter_label(0);
  if (!PyArg_ParseTupleAndKeywords(args, kws, "|OOOOOO:OpenDialog", kwlist, &title, &multiple_selection, &starting_location, &button_caption, &filter_object, &filter_label))
    return NULL;

  ESRI_OLE_HANDLE hApp;
  ipApp->get_hWnd(&hApp);

  IGxDialogPtr ipGxDialog(CLSID_GxDialog);

  if (!ipGxDialog)
    Py_RETURN_NONE;

  SetupDialog(ipGxDialog, title, multiple_selection, Py_None, starting_location, button_caption, filter_object, filter_label);

  IEnumGxObjectPtr ipSel;
  VARIANT_BOOL result;
  
  if (SUCCEEDED(ipGxDialog->DoModalOpen(hApp, &ipSel, &result)) && result && ipSel)
  {
    if (PyObject_IsTrue(multiple_selection))
    {
      ipSel->Reset();
      PyObject* items = PyList_New(0);
      IGxObjectPtr ipGxObj;
      _bstr_t name;

      while (SUCCEEDED(ipSel->Next(&ipGxObj)) && ipGxObj)
      {
        ipGxObj->get_FullName(at(name));

        PyObject* fullName(PyUnicode_FromWideChar(name, (Py_ssize_t)::SysStringLen(name)));
        PyList_Append(items, fullName);
        Py_XDECREF(fullName);
      }

      return items;
    }
    else
    {
      ipSel->Reset();
      PyObject* items = PyList_New(0);
      IGxObjectPtr ipGxObj;
      _bstr_t name;

      if (SUCCEEDED(ipSel->Next(&ipGxObj)) && ipGxObj)
      {
        ipGxObj->get_FullName(at(name));

        return PyUnicode_FromWideChar(name, (Py_ssize_t)::SysStringLen(name));
      }
    }
  }

  Py_RETURN_NONE;
}

PyObject* SaveDialog(PyObject* self, PyObject* args, PyObject* kws)
{
  static char *kwlist[] = {"title", "name_text", "starting_location", "filter", "filter_label", NULL};

  IApplicationPtr ipApp;
  HRESULT hr = ipApp.CreateInstance(CLSID_AppRef);

  if(FAILED(hr) || !ipApp)
  {
    PyErr_SetString(PyExc_RuntimeError, "Not running in a desktop application.");
    return 0;
  }

  PyObject *title(Py_None),
           *name_text(Py_None),
           *starting_location(Py_None),
           *button_caption(Py_None),
           *filter_object(0),
           *filter_label(0);
  if (!PyArg_ParseTupleAndKeywords(args, kws, "|OOOOO:SaveDialog", kwlist, &title, &name_text, &starting_location, &filter_object, &filter_label))
    return NULL;

  ESRI_OLE_HANDLE hApp;
  ipApp->get_hWnd(&hApp);

  IGxDialogPtr ipGxDialog(CLSID_GxDialog);

  if (!ipGxDialog)
    Py_RETURN_NONE;

  SetupDialog(ipGxDialog, title, Py_None, name_text, starting_location, button_caption, filter_object, filter_label);

  VARIANT_BOOL result;

  if (SUCCEEDED(ipGxDialog->DoModalSave(hApp, &result)) && result)
  {
    _bstr_t path, name;
    IGxObjectPtr ipLocation;
    ipGxDialog->get_FinalLocation(&ipLocation);
    ipLocation->get_FullName(at(path));
    ipGxDialog->get_Name(at(name));

    py_obj pathobj(PyUnicode_FromWideChar(path, (Py_ssize_t)::SysStringLen(path))),
           nameobj(PyUnicode_FromWideChar(name, (Py_ssize_t)::SysStringLen(name)));

    py_obj path_tuple = Py_BuildValue("OO", (PyObject*)pathobj, (PyObject*)nameobj);

    py_obj os(PyImport_ImportModule("os"));
    if (os)
    {
      py_obj path(PyObject_GetAttrString(os, "path"));
      if (path)
      {
        py_obj join(PyObject_GetAttrString(path, "join"));

        if (join)
          return PyObject_Call(join, path_tuple, 0);
      }
    }

    Py_INCREF((PyObject*)path_tuple);
    return path_tuple;
  }

  Py_RETURN_NONE;
}

static std::vector<IGPToolCommandHelper2Ptr>* g_pToolCommands(NULL);
static UINT TIMER_ID(0);

VOID CALLBACK GPToolDialogCallback(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
  if (g_pToolCommands != NULL)
  {
    for (std::vector<IGPToolCommandHelper2Ptr>::const_iterator it(g_pToolCommands->begin());
         it != g_pToolCommands->end();
         ++it)
    {
      (*it)->Invoke(NULL);
    }

    delete g_pToolCommands;
    g_pToolCommands = NULL;
  }

  ::KillTimer(hwnd, idEvent);
}

void RegisterToolCall(ESRI_OLE_HANDLE hWnd, IGPToolCommandHelper2Ptr ipDialog)
{
  if (g_pToolCommands == NULL)
  {
    g_pToolCommands = new std::vector<IGPToolCommandHelper2Ptr>();
  }
  g_pToolCommands->push_back(ipDialog);
  ::SetTimer(hWnd, TIMER_ID, USER_TIMER_MINIMUM, GPToolDialogCallback);
}

PyObject* GPToolDialog(PyObject* self, PyObject* args, PyObject* kws)
{
  static char *skwlist[] = {"tool_name", NULL};
  static char *kwlist[] = {"toolbox", "tool_name", NULL};

  IApplicationPtr ipApp;
  HRESULT hr = ipApp.CreateInstance(CLSID_AppRef);

  if(FAILED(hr) || !ipApp)
  {
    PyErr_SetString(PyExc_RuntimeError, "Not running in a desktop application.");
    return 0;
  }

  ESRI_OLE_HANDLE hApp;
  ipApp->get_hWnd(&hApp);

  PyObject *py_toolbox(Py_None),
           *py_tool_name(Py_None);

  IGPToolCommandHelper2Ptr ipHelper(CLSID_GPToolCommandHelper);

  if (PyArg_ParseTupleAndKeywords(args, kws, "O:GPToolDialog", skwlist, &py_tool_name))
  {
    IGPToolPtr ipTool;

    _bstr_t tool_name(utils::toString(py_tool_name));

    IGPHolderPtr ipGPHolder(CLSID_GPHolder);
    IGeoProcessorImplPtr ipGP;
    if (ipGPHolder)
    {
      ipGPHolder->get_GeoProcessorFromGpScriptBase(&ipGP);
    }
    if (ipGP)
    {
      ipGP->GetToolbyNameString(tool_name, &ipTool);
    }

    if (ipTool)
    {
      ipHelper->SetTool(ipTool);
      RegisterToolCall(hApp, ipHelper);
      Py_RETURN_NONE;
    }
  }

  if (!PyArg_ParseTupleAndKeywords(args, kws, "OO:GPToolDialog", kwlist, &py_toolbox, &py_tool_name))
    return NULL;

  _bstr_t toolbox_name(utils::toString(py_toolbox));
  _bstr_t tool_name(utils::toString(py_tool_name));

  if (SUCCEEDED(ipHelper->SetToolByName(toolbox_name, tool_name)))
  {
    RegisterToolCall(hApp, ipHelper);
    Py_RETURN_NONE;
  }

  py_obj error_object(Py_BuildValue("(OO)", py_toolbox, py_tool_name));
  PyErr_SetObject(PyExc_ValueError, error_object);
  return NULL;
}

PyObject* PopupMessageBox(PyObject* self, PyObject* args, PyObject* kws)
{
  static char *kwlist[] = {"message", "title", "mb_type", NULL};

  IApplicationPtr ipApp;
  HRESULT hr = ipApp.CreateInstance(CLSID_AppRef);

  if(FAILED(hr) || !ipApp)
  {
    PyErr_SetString(PyExc_RuntimeError, "Not running in a desktop application.");
    return 0;
  }

  PyObject *py_message(Py_None),
           *py_title(Py_None),
           *py_type(Py_None);
  if (!PyArg_ParseTupleAndKeywords(args, kws, "OO|O:MessageBox", kwlist, &py_message, &py_title, &py_type))
    return NULL;

  ESRI_OLE_HANDLE hApp;
  ipApp->get_hWnd(&hApp);

  _bstr_t message(utils::toString(py_message)),
          title(utils::toString(py_title));

  int message_type(0);

  if (PyNumber_Check(py_type))
  {
    switch (PyNumber_AsSsize_t(py_type, NULL))
    {
    //0 - OK
    case 0:
      message_type = MB_OK;
      break;
    //1 - OK/CANCEL
    case 1:
      message_type = MB_OKCANCEL;
      break;
    //2 - ABORT/RETRY/IGNORE
    case 2:
      message_type = MB_ABORTRETRYIGNORE;
      break;
    //3 - YES/NO/CANCEL
    case 3:
      message_type = MB_YESNOCANCEL;
      break;
    //4 - YES/NO
    case 4:
      message_type = MB_YESNO;
      break;
    //5 - RETRY/CANCEL
    case 5:
      message_type = MB_RETRYCANCEL;
      break;
    //6 - CANCEL/TRY AGAIN/CONTINUE
    case 6:
      message_type = MB_CANCELTRYCONTINUE;
      break;
    default:
      message_type = MB_OK;
    }
  }

  int return_value(MessageBox(hApp, message, title, message_type));

  _bstr_t return_string;
  switch (return_value)
  {
  case IDOK:
    return_string = _T("OK");
    break;
  case IDABORT:
    return_string = _T("Abort");
    break;
  case IDCANCEL:
    return_string = _T("Cancel");
    break;
  case IDCONTINUE:
    return_string = _T("Continue");
    break;
  case IDIGNORE:
    return_string = _T("Ignore");
    break;
  case IDNO:
    return_string = _T("No");
    break;
  case IDRETRY:
    return_string = _T("Retry");
    break;
  case IDTRYAGAIN:
    return_string = _T("Try Again");
    break;
  case IDYES:
    return_string = _T("Yes");
    break;
  default:
    break;
  }

  if (return_string.length())
    return PyUnicode_FromWideChar(return_string, return_string.length());
  else
    Py_RETURN_NONE;
}

PyObject* GetSelectedTOCLayerOrDataFrame(PyObject* self, PyObject* args, PyObject* kws)
{
  IApplicationPtr ipApp;
  HRESULT hr = ipApp.CreateInstance(CLSID_AppRef);

  if(FAILED(hr) || !ipApp)
  {
    PyErr_SetString(PyExc_RuntimeError, "Not running in a desktop application.");
    return 0;
  }

  IDocumentPtr ipDoc;
  ipApp->get_Document(&ipDoc);
  IMxDocumentPtr ipMXDoc(ipDoc);
  IContentsViewPtr ipContentsView;

  if (ipMXDoc)
    ipMXDoc->get_CurrentContentsView(&ipContentsView);

  _variant_t item;

  if (ipContentsView)
    ipContentsView->get_SelectedItem(&item);

  if (item.vt == VT_UNKNOWN)
  {
    IMapPtr ipMap(item.punkVal);
    ILayerPtr ipLayer(item.punkVal);
    ISetPtr ipSet(item.punkVal);

    if (ipMap)
    {
      return utils::AsPythonDataFrame(ipMap);
    }
    else if (ipLayer)
    {
      return utils::AsPythonLayer(ipLayer);
    }
	  else if (ipSet)
	  {
      ipSet->Reset();
      IUnknownPtr ipUnk;
      PyObject* return_val = PyList_New(0);

      while (SUCCEEDED(ipSet->Next(&ipUnk)) && ipUnk)
      {
        PyObject* pItem(0);
        IMapPtr ipObjectMap(ipUnk);
        ILayerPtr ipObjectLayer(ipUnk);

        if (ipObjectMap)
        {
          pItem = utils::AsPythonDataFrame(ipObjectMap);
        }
        else if (ipObjectLayer)
        {
          pItem = utils::AsPythonLayer(ipObjectLayer);
        }

        if (pItem)
        {
          PyList_Append(return_val, pItem);
        }

        Py_CLEAR(pItem);
      }

      return return_val;
    }
  }

  Py_RETURN_NONE;
}

PyObject* GetSelectedCatalogWindowPath(PyObject* self, PyObject* args, PyObject* kws)
{
  IApplicationPtr ipApp;
  HRESULT hr = ipApp.CreateInstance(CLSID_AppRef);
  IGxApplicationPtr ipGX(ipApp);

  if(FAILED(hr) || !ipApp || !ipGX)
  {
    PyErr_SetString(PyExc_RuntimeError, "Not running in a desktop application.");
    return 0;
  }

  IGxObjectPtr ipObjectPtr;
  ipGX->get_SelectedObject(&ipObjectPtr);

  if (ipObjectPtr)
  {
    _bstr_t pathName;
    ipObjectPtr->get_FullName(at(pathName));

    return PyUnicode_FromWideChar(pathName, (Py_ssize_t)::SysStringLen(pathName));
  }

  Py_RETURN_NONE;
}

PyObject* WriteStringToPythonWindow(PyObject* self, PyObject* args, PyObject* kws)
{
  static char *kwlist[] = {"text", "start_newline", "reprompt_when_done", "is_error", NULL};

  IApplicationPtr ipApp;
  HRESULT hr = ipApp.CreateInstance(CLSID_AppRef);

  if(FAILED(hr) || !ipApp)
  {
    PyErr_SetString(PyExc_RuntimeError, "Not running in a desktop application.");
    return 0;
  }

  PyObject *line_text(Py_None),
           *newline(Py_True),
           *reprompt(Py_True),
           *is_error(Py_None);
  if (!PyArg_ParseTupleAndKeywords(args, kws, "O|OOO:WriteStringToPythonWindow", kwlist, &line_text, &newline, &reprompt, &is_error))
    return NULL;

  IGPCommandWindowAccessImplPtr ipPythonWindow(CLSID_GPCommandWindow);
  if (ipPythonWindow)
  {
    _bstr_t lintetextstring(utils::toString(line_text));

    VARIANT_BOOL isNewline = PyObject_IsTrue(newline) ? VARIANT_TRUE : VARIANT_FALSE;
    if (PyObject_IsTrue(is_error))
      ipPythonWindow->WriteStderr(lintetextstring, isNewline);
    else
      ipPythonWindow->WriteStdout(lintetextstring, isNewline);
    if (PyObject_IsTrue(reprompt))
      ipPythonWindow->Reprompt();
  }

  Py_RETURN_NONE;
}

};