/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
// extension.cpp : Implementation of Extensions

#include "stdafx.h"
#include "extension.h"
#include "constants.h"
#include "utils.h"
#include "PythonExecuteWait.h"

EditorExtensionUpdater::EditorExtensionUpdater(PyObject* wrapObject, IEditorPtr ipWrapEditor, bool clearAttrsWhenFinished) 
    : m_pPyObject(wrapObject),
      m_ipEditor(ipWrapEditor),
      m_clearAttrs(clearAttrsWhenFinished)
{
  if (m_pPyObject)
  {
    Py_INCREF(wrapObject);
    PyObject_SetAttrString(m_pPyObject, s_editworkspace, Py_None);
    PyObject_SetAttrString(m_pPyObject, s_currentlayer, Py_None);
    PyObject_SetAttrString(m_pPyObject, s_currentfeature, Py_None);
    PyObject_SetAttrString(m_pPyObject, s_editselection, Py_None);
  }

  if (m_pPyObject && m_ipEditor)
  {
    IWorkspacePtr ipWS;
    m_ipEditor->get_EditWorkspace(&ipWS);
    if (ipWS)
    {
      _bstr_t path_name;
      ipWS->get_PathName(at(path_name));
      py_obj workspace_path(PyUnicode_FromWideChar(path_name, ::SysStringLen(path_name)));
      PyObject_SetAttrString(m_pPyObject, s_editworkspace, workspace_path);
    }

    IEnumFeaturePtr ipEF;
    m_ipEditor->get_EditSelection(&ipEF);
    IGeometryPtr ipAllGeometry;
    if (ipEF)
    {
      py_obj oid_set(PyList_New(0));
      IFeaturePtr ipF;
      VARIANT_BOOL HOID;
      long oid;
      while (SUCCEEDED(ipEF->Next(&ipF)) && ipF)
      {
        if (SUCCEEDED(ipF->get_HasOID(&HOID)) && HOID == VARIANT_TRUE)
        {
          ipF->get_OID(&oid);
          py_obj new_long(PyInt_FromLong(oid));
          PyList_Append(oid_set, new_long);
        }

        if (!ipAllGeometry)
        {
          ipF->get_ShapeCopy(&ipAllGeometry);
        }
        else
        {
          ITopologicalOperatorPtr ipTopo(ipAllGeometry);
          IGeometryPtr ipGeom;

          VARIANT_BOOL vbGeomBroken(VARIANT_TRUE);
          ipF->get_Shape(&ipGeom);
          if (ipGeom)
          {
            ipGeom->get_IsEmpty(&vbGeomBroken);
          }

          if (ipTopo && vbGeomBroken == VARIANT_FALSE)
          {
            ipTopo->Union(ipGeom, &ipAllGeometry);
          }
        }
      }

      PyObject_SetAttrString(m_pPyObject, s_editselection, oid_set);
    }

    IEditLayersPtr ipEditLayers(m_ipEditor);
    if (ipEditLayers)
    {
      IFeatureLayerPtr ipFL;
      ipEditLayers->get_CurrentLayer(&ipFL);
      if (ipFL)
      {
        py_obj layer(utils::AsPythonLayer(ILayerPtr(ipFL)));
        PyObject_SetAttrString(m_pPyObject, s_currentlayer, layer);
      }
    }

    bool set_geometry(false);
    IEditSketchPtr ipEditSketch(m_ipEditor);
    if (ipEditSketch)
    {
      IGeometryPtr ipGeom;
      ipEditSketch->get_Geometry(&ipGeom);
      if (ipGeom)
      {
        VARIANT_BOOL vbEmpty(VARIANT_TRUE);

        ipGeom->get_IsEmpty(&vbEmpty);
        if (vbEmpty == VARIANT_FALSE)
        {
          py_obj geometry(utils::AsPythonGeometry(ipGeom));
          PyObject_SetAttrString(m_pPyObject, s_currentfeature, geometry);
          set_geometry = true;
        }
      }
    }

    if (!set_geometry && ipAllGeometry)
    {
      VARIANT_BOOL vbEmpty(VARIANT_TRUE);
      ipAllGeometry->get_IsEmpty(&vbEmpty);
      if (vbEmpty == VARIANT_FALSE)
      {
        py_obj geometry(utils::AsPythonGeometry(ipAllGeometry));
        PyObject_SetAttrString(m_pPyObject, s_currentfeature, geometry);
        set_geometry = true;
      }
    }
  }
}
EditorExtensionUpdater::~EditorExtensionUpdater()
{
  if (m_clearAttrs && m_pPyObject)
  {
    PyObject_SetAttrString(m_pPyObject, s_editworkspace, Py_None);
    PyObject_SetAttrString(m_pPyObject, s_currentlayer, Py_None);
    PyObject_SetAttrString(m_pPyObject, s_currentfeature, Py_None);
    PyObject_SetAttrString(m_pPyObject, s_editselection, Py_None);
  }
}

//IExtension
STDMETHODIMP wrap_extension::get_Name(BSTR * extensionName)
{
  *extensionName = m_id.copy();
  return S_OK;
}

STDMETHODIMP wrap_extension::Startup(VARIANT * initializationData)
{
  ResetEditorAttributes();
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_startup))
  {
    PythonExecuteWait RunWrap;

    py_obj ret = PyObject_CallMethod(m_pyObj, s_startup, NULL);
  }
  RegisterEventSinks();
  return S_OK;
}

STDMETHODIMP wrap_extension::Shutdown()
{
  ResetEditorAttributes();
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_shutdown))
  {
    PythonExecuteWait RunWrap;

    py_obj ret = PyObject_CallMethod(m_pyObj, s_shutdown, NULL);
  }
  UnregisterEventSinks();
  return S_OK;
}

//IExtensionConfig
STDMETHODIMP wrap_extension::get_ProductName(BSTR * Name)
{
  *Name = m_name.copy();
  return S_OK;
}

STDMETHODIMP wrap_extension::get_Description(BSTR * Description)
{
  *Description = m_description.copy();
  return S_OK;
}

STDMETHODIMP wrap_extension::get_State(esriExtensionState * State)
{
  if (!m_pyObj)
  {
    *State = esriESUnavailable;
    return S_OK;
  }
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_enabled))
  {
    PythonExecuteWaitNoCursor RunWrap;

    py_obj active = PyObject_GetAttrString(m_pyObj, s_enabled);
    *State = PyObject_IsTrue(active) ? esriESEnabled : esriESDisabled;
  }
  else
    *State = esriESEnabled;
  return S_OK;
}

STDMETHODIMP wrap_extension::put_State(esriExtensionState State)
{
  if (m_pyObj)
  {
    PythonExecuteWaitNoCursor RunWrap;

    if (State == esriESEnabled && PyObject_HasAttrString(m_pyObj, s_enabled))
    {
      PyObject_SetAttrString(m_pyObj, s_enabled, Py_True);
      RegisterEventSinks();
    }
    else if (PyObject_HasAttrString(m_pyObj, s_enabled))
    {
      PyObject_SetAttrString(m_pyObj, s_enabled, Py_False);
      UnregisterEventSinks();
    }
  }
  return S_OK;
}

//IDocumentEvents
STDMETHODIMP wrap_extension::ActiveViewChanged( )
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_activeViewChanged))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_activeViewChanged, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::MapsChanged( )
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_mapsChanged))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_mapsChanged, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnContextMenu(long x, long y, VARIANT_BOOL * handled )
{
  *handled = VARIANT_FALSE;
  return S_OK;
}

STDMETHODIMP wrap_extension::NewDocument( )
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_newDocument))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_newDocument, NULL);
  }
  RegisterDocumentSpecificEventSinks(false);
  return S_OK;
}

STDMETHODIMP wrap_extension::OpenDocument( )
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_openDocument))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_openDocument, NULL);
  }
  RegisterDocumentSpecificEventSinks(false);
  return S_OK;
}

STDMETHODIMP wrap_extension::BeforeCloseDocument( VARIANT_BOOL * abortClose )
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_beforeCloseDocument))
  {
    PythonExecuteWait RunWrap;
    py_obj retval = PyObject_CallMethod(m_pyObj, s_beforeCloseDocument, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::CloseDocument( )
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_closeDocument))
  {
    PythonExecuteWait RunWrap;
    py_obj retval = PyObject_CallMethod(m_pyObj, s_closeDocument, NULL);
  }
  return S_OK;
}

//IPageIndexEvents
STDMETHODIMP wrap_extension::BeforePageIndexExtentChange( long oldID )
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_beforePageIndexExtentChange))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_beforePageIndexExtentChange, "l", oldID);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::PageIndexExtentChanged( long curID )
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_pageIndexExtentChanged))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_pageIndexExtentChanged, "l", curID);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::BeforePageIndexRefresh( )
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_beforePageIndexRefresh))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_beforePageIndexRefresh, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::PageIndexRefreshed( )
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_pageIndexRefreshed))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_pageIndexRefreshed, NULL);
  }
  return S_OK;
}

//IActiveViewEvents
STDMETHODIMP wrap_extension::ContentsChanged()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_contentsChanged))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_contentsChanged, NULL);
  }
  RegisterDocumentSpecificEventSinks(true);
  return S_OK;
}

STDMETHODIMP wrap_extension::ContentsCleared()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_contentsCleared))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_contentsCleared, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::ItemAdded(VARIANT Item)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_itemAdded))
  {
    PythonExecuteWait RunWrap;
    py_obj return_object(utils::VariantAsKnownPyObject(Item));

    py_obj retval = PyObject_CallMethod(m_pyObj, s_itemAdded, "O", (PyObject*)return_object);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::ItemDeleted(VARIANT Item)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_itemDeleted))
  {
    PythonExecuteWait RunWrap;
    py_obj return_object(utils::VariantAsKnownPyObject(Item));

    py_obj retval = PyObject_CallMethod(m_pyObj, s_itemDeleted, "O", (PyObject*)return_object);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::ItemReordered(VARIANT Item, long toIndex)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_itemReordered))
  {
    PythonExecuteWait RunWrap;
    py_obj return_object(utils::VariantAsKnownPyObject(Item));

    py_obj retval = PyObject_CallMethod(m_pyObj, s_itemReordered, "Oi", (PyObject*)return_object, toIndex);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::SelectionChanged()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_selectionChanged))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_selectionChanged, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::ViewRefreshed(struct IActiveView * view, enum esriViewDrawPhase phase, VARIANT Data, struct IEnvelope * envelope)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  return S_OK;
}

STDMETHODIMP wrap_extension::AfterDraw(struct IDisplay * Display, enum esriViewDrawPhase phase)
{
  return S_OK;
}

STDMETHODIMP wrap_extension::AfterItemDraw(short Index, struct IDisplay * Display, enum esriDrawPhase phase)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  return S_OK;
}

STDMETHODIMP wrap_extension::FocusMapChanged()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_focusMapChanged))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_focusMapChanged, NULL);
  }
  return S_OK;
}

//IEditEvents
STDMETHODIMP wrap_extension::OnSelectionChanged()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onEditorSelectionChanged))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onEditorSelectionChanged, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnCurrentLayerChanged()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onCurrentLayerChanged))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onCurrentLayerChanged, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnCurrentTaskChanged()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onCurrentTaskChanged))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onCurrentTaskChanged, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnSketchModified()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onSketchModified))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onSketchModified, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnSketchFinished()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onSketchFinished))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onSketchFinished, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::AfterDrawSketch(IDisplay* pDpy)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_afterDrawSketch))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_afterDrawSketch, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnStartEditing()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onStartEditing))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onStartEditing, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnStopEditing(VARIANT_BOOL save)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onStopEditing))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onStopEditing, "O", save ? Py_True : Py_False);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnConflictsDetected()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onConflictsDetected))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onConflictsDetected, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnUndo()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onUndo))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onUndo, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnRedo()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onRedo))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onRedo, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnCreateFeature(IObject* obj)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onCreateFeature))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onCreateFeature, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnChangeFeature(IObject* obj)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onChangeFeature))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onChangeFeature, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnDeleteFeature(IObject* obj)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onDeleteFeature))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onDeleteFeature, NULL);
  }
  return S_OK;
}

//IEditEvents2
STDMETHODIMP wrap_extension::OnCurrentZChanged()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onCurrentZChanged))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onCurrentZChanged, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnVertexMoved(IPoint* point)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onVertexMoved))
  {
    PythonExecuteWait RunWrap;
    
    IGeometryPtr ipPoint(point);
    py_obj vertex_pt(utils::AsPythonGeometry(ipPoint));
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onVertexMoved, "O", (bool)vertex_pt ? vertex_pt : Py_None);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnVertexAdded(IPoint* point)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onVertexAdded))
  {
    PythonExecuteWait RunWrap;
    
    IGeometryPtr ipPoint(point);
    py_obj vertex_pt(utils::AsPythonGeometry(ipPoint));
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onVertexAdded, "O", (bool)vertex_pt ? vertex_pt : Py_None);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnVertexDeleted(IPoint* point)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onVertexDeleted))
  {
    PythonExecuteWait RunWrap;
    
    IGeometryPtr ipPoint(point);
    py_obj vertex_pt(utils::AsPythonGeometry(ipPoint));
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onVertexDeleted, "O", (bool)vertex_pt ? vertex_pt : Py_None);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::BeforeStopEditing(VARIANT_BOOL save)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_beforeStopEditing))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_beforeStopEditing, "O", save ? Py_True : Py_False);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnAbort()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onAbort))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onAbort, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnStartOperation()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onStartOperation))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onStartOperation, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::BeforeStopOperation()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_beforeStopOperation))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_beforeStopOperation, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnStopOperation()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onStopOperation))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onStopOperation, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnSaveEdits()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onSaveEdits))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onSaveEdits, NULL);
  }
  return S_OK;
}

//IEditEvents3
STDMETHODIMP wrap_extension::BeforeDrawSketch(IDisplay* pDpy)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_beforeDrawSketch))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_beforeDrawSketch, NULL);
  }
  return S_OK;
}

//IEditEvents4
STDMETHODIMP wrap_extension::OnUseGroundToGridChanged(VARIANT_BOOL g2g)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onUseGroundToGridChanged))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onUseGroundToGridChanged, "O", g2g ? Py_True : Py_False);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnAngularCorrectionOffsetChanged(double angOffset)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onAngularCorrectionOffsetChanged))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onAngularCorrectionOffsetChanged, "d", angOffset);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnDistanceCorrectionFactorChanged(double distFactor)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onDistanceCorrectionFactorChanged))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onDistanceCorrectionFactorChanged, "d", distFactor);
  }
  return S_OK;
}
//IEditEvents5
STDMETHODIMP wrap_extension::OnCurrentTemplateChanged(IEditTemplate* editTemplate)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onCurrentTemplateChanged))
  {
    PythonExecuteWait RunWrap;
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onCurrentTemplateChanged, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnTemplatesRemoved(IArray* editTemplates)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onTemplatesRemoved))
  {
    PythonExecuteWait RunWrap;
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onTemplatesRemoved, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnTemplatesAdded(IArray* editTemplates)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onTemplatesAdded))
  {
    PythonExecuteWait RunWrap;
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onTemplatesAdded, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnTemplateModified(IEditTemplate* editTemplate)
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onTemplateModified))
  {
    PythonExecuteWait RunWrap;
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onTemplateModified, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnVertexSelectionChanged()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onVertexSelectionChanged))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onVertexSelectionChanged, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::OnShapeConstructorChanged()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_onShapeConstructorChanged))
  {
    PythonExecuteWait RunWrap;
    
    py_obj retval = PyObject_CallMethod(m_pyObj, s_onShapeConstructorChanged, NULL);
  }
  return S_OK;
}

STDMETHODIMP wrap_extension::SpatialReferenceChanged()
{
  utils::EventLock here(&m_eventDepth);
  if (!here.OneDeep())
  {
    return S_OK;
  }

  EditorExtensionUpdater editAttribsHere(m_pyObj, m_ipEditor);
  if (m_pyObj && PyObject_HasAttrString(m_pyObj, s_spatialReferenceChanged))
  {
    PythonExecuteWait RunWrap;

    py_obj retval = PyObject_CallMethod(m_pyObj, s_spatialReferenceChanged, NULL);
  }
  return S_OK;
}

void wrap_extension::UnregisterDocumentSpecificEventSinks(bool ddp_only)
{
  if (!ddp_only)
  {
    if (m_ActiveViewEvents)
    {
      if (m_ipActiveView)
      {
        m_ipActiveViewEvents->Unadvise(m_ipActiveView);
        m_ipActiveView = 0;
      }
      m_ActiveViewEvents = false;
    }
  }

  if (m_DDPEvents)
  {
    if (m_ipPageLayout)
    {
      m_ipDDPEvents->Unadvise(m_ipPageLayout);
      m_ipPageLayout = 0;
    }
    m_DDPEvents = false;
  }
}

void wrap_extension::RegisterDocumentSpecificEventSinks(bool ddp_only)
{
  UnregisterDocumentSpecificEventSinks(ddp_only);
  IDocumentPtr ipDoc;
  IPageLayoutPtr ipPageLayout;
  if (m_ipApp)
    m_ipApp->get_Document(&ipDoc);
  IMxDocumentPtr ipMXDoc(ipDoc);

  if (!ddp_only)
  {
    if (ipMXDoc)
      ipMXDoc->get_ActiveView(&m_ipActiveView);
    if (m_ipActiveView)
    {
      if (m_ipActiveViewEvents && SUCCEEDED(m_ipActiveViewEvents->Advise(static_cast<IActiveViewEvents*>(this), 
                                                                         (GUID*)&IID_IActiveViewEvents, 
                                                                         m_ipActiveView)))
        m_ActiveViewEvents = true;
    }
  }

  if (ipMXDoc)
    ipMXDoc->get_PageLayout(&ipPageLayout);
  m_ipPageLayout = ipPageLayout;
  if (m_ipPageLayout)
  {
    if (m_ipDDPEvents && SUCCEEDED(m_ipDDPEvents->Advise(static_cast<IPageIndexEvents*>(this), 
                                                         (GUID*)&IID_IPageIndexEvents, 
                                                         m_ipPageLayout)))
      m_DDPEvents = true;
  }
}

void wrap_extension::RegisterEventSinks()
{
  // Cleanup (just in case)
  UnregisterEventSinks();
  // Hook in on events we need to look at
  if (m_pyObj)
  {

    if (m_ipApp)
      m_ipApp->get_Document(&m_ipDoc);
    if (m_ipDoc && m_ipDocEvents)
    {
      if (m_ipDocEvents && SUCCEEDED(m_ipDocEvents->Advise(static_cast<IDocumentEvents*>(this),
                                                           (GUID*)&IID_IDocumentEvents,
                                                           m_ipDoc)))
        m_DocumentEvents = true;
    }
    IDocumentPtr ipDoc;
    if (m_ipApp)
      m_ipApp->get_Document(&ipDoc);
    if (m_ipEditor)
    {
      m_ipEditorEvents.CreateInstance(CLSID_EditEventsHelper);
      m_ipEditorEvents2.CreateInstance(CLSID_EditEvents2Helper);
      m_ipEditorEvents3.CreateInstance(CLSID_EditEvents3Helper);
      m_ipEditorEvents4.CreateInstance(CLSID_EditEvents4Helper);
      m_ipEditorEvents5.CreateInstance(CLSID_EditEvents5Helper);

      if (m_ipEditorEvents && FAILED(m_ipEditorEvents->Advise(static_cast<IEditEvents*>(this), 
                                                              (GUID*)&IID_IEditEvents, 
                                                              m_ipEditor)))
        m_ipEditorEvents = 0;
      if (m_ipEditorEvents2 && FAILED(m_ipEditorEvents2->Advise(static_cast<IEditEvents2*>(this),
                                                                (GUID*)&IID_IEditEvents2,
                                                                m_ipEditor)))
        m_ipEditorEvents2 = 0;
      if (m_ipEditorEvents3 && FAILED(m_ipEditorEvents3->Advise(static_cast<IEditEvents3*>(this),
                                                                (GUID*)&IID_IEditEvents3,
                                                                m_ipEditor)))
        m_ipEditorEvents3 = 0;
      if (m_ipEditorEvents4 && FAILED(m_ipEditorEvents4->Advise(static_cast<IEditEvents4*>(this),
                                                                (GUID*)&IID_IEditEvents4,
                                                                m_ipEditor)))
        m_ipEditorEvents4 = 0;
      if (m_ipEditorEvents5 && FAILED(m_ipEditorEvents5->Advise(static_cast<IEditEvents5*>(this),
                                                                (GUID*)&IID_IEditEvents5,
                                                                m_ipEditor)))
        m_ipEditorEvents5 = 0;

      if (m_ipEditorEvents  ||
          m_ipEditorEvents2 ||
          m_ipEditorEvents3 ||
          m_ipEditorEvents4 ||
          m_ipEditorEvents5)
        m_EditEvents = true;
    }
    RegisterDocumentSpecificEventSinks(false);
  }
}

void wrap_extension::UnregisterEventSinks()
{
  if (m_DocumentEvents)
  {
    if (m_ipDoc)
    {
      m_ipDocEvents->Unadvise(m_ipDoc);
      m_ipDoc = 0;
    }
    m_DocumentEvents = false;
  }
  UnregisterDocumentSpecificEventSinks(false);
  if (m_EditEvents)
  {
    if (m_ipEditor)
    {
      if (m_ipEditorEvents)
        m_ipEditorEvents->Unadvise(m_ipEditor);
      if (m_ipEditorEvents2)
        m_ipEditorEvents2->Unadvise(m_ipEditor);
      if (m_ipEditorEvents3)
        m_ipEditorEvents3->Unadvise(m_ipEditor);
      if (m_ipEditorEvents4)
        m_ipEditorEvents4->Unadvise(m_ipEditor);
      if (m_ipEditorEvents5)
        m_ipEditorEvents5->Unadvise(m_ipEditor);
    }
    m_EditEvents = false;
  }
}

void wrap_extension::ResetEditorAttributes()
{
  if (m_pyObj)
  {
    // Reset special Editor event attributes
    PyObject_SetAttrString(m_pyObj, s_editworkspace, Py_None);
    PyObject_SetAttrString(m_pyObj, s_currentlayer, Py_None);
    PyObject_SetAttrString(m_pyObj, s_currentfeature, Py_None);
    PyObject_SetAttrString(m_pyObj, s_editselection, Py_None);
  }
}
