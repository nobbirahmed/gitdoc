/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#include "StdAfx.h"
#include "utils.h"
#include "constants.h"
#include "PythonExecuteWait.h"

void event_base::forward_call0(list_type& list, const char* method0)
{
  PythonExecuteWaitNoCursor WaitHere;

  list_type::const_iterator it = list.begin();
  while (it != list.end())
  {      
    utils::call_member0(const_cast<PyObject*>(*it), method0);
    ++it;

    WaitHere.PumpError();
  }
}

void control::initControl(const bstr_t& id, PyObject* obj, PyObject* pModuleDict)
{ 
  m_id = id;
  ATLASSERT(m_pyObj == NULL);
  m_pyObj = obj;     
  Py_XINCREF(obj);
  m_pDict = pModuleDict; //weak ptr
}

void utils::dict_keys(PyObject* pDict)
{ 
  PyObject *key, *value;
  Py_ssize_t pos = 0;
  
  while (PyDict_Next(pDict, &pos, &key, &value)) 
  {
    py_obj keyrepr = PyObject_Repr(key);
    py_obj valrepr = PyObject_Repr(value);
    ATLTRACE("\nkey: %s : %s", PyString_AS_STRING((PyObject*)keyrepr), PyString_AS_STRING((PyObject*)valrepr));
  }  
}

bool utils::attr(PyObject* pyObj, const char* attr, bstr_t &val)
{  
  if (pyObj != NULL && PyObject_HasAttrString(pyObj, attr))
  {
    py_obj ret = PyObject_GetAttrString(pyObj, attr);    
    if (PyCallable_Check(ret))
    {
      ret = PyObject_CallObject(ret, NULL);
      ATLASSERT(!ret.isNull());
    }
    val = toString(ret);
    return true;
  }
  return false;
}

bool utils::attr(PyObject* pyObj, const char* attr, bool &val)
{
  if (pyObj && PyObject_HasAttrString(pyObj, attr))
  {    
    py_obj ret = PyObject_GetAttrString(pyObj, attr);    
    ATLASSERT(!ret.isNull());
    if (PyCallable_Check(ret))
    {
      ret = PyObject_CallObject(ret, NULL);
      ATLASSERT(!ret.isNull());
    }
    
    if (!PyBool_Check(ret))
    {
      ATLTRACE("not boolean (%s)", attr);
      return false;
    }
    //val = (PyObject_IsTrue(ret) != 0);
    val = Py_True == (PyObject*)ret;
    return true;
  }
  return false;
}

bool utils::attr(PyObject* pyObj, const char* attr, long &val)
{
  if (!pyObj)
    return false;
  
  PyObject* ret = NULL;
  if (PyDict_Check(pyObj))
    ret = PyDict_GetItemString(pyObj, attr);
  else
    if (PyObject_HasAttrString(pyObj, attr))
      ret = PyObject_GetAttrString(pyObj, attr); 
  
  PyErr_Clear();
  if (!ret)
    return false;
  
  if (PyNumber_Check(ret))
  {
   py_obj asint = PyNumber_Int(ret);
   if (asint.isNull())
     return false;

   val = PyInt_AsLong(asint);
   return true;
  }

  PyErr_Clear();
  return false;
}

const bstr_t utils::toString(PyObject* pObj)
{
  if (!pObj)
    return bstr_t();

  if (PyString_Check(pObj))
    return PyString_AS_STRING(pObj);
  else if (PyUnicode_Check(pObj))
    return PyUnicode_AS_UNICODE(pObj);
  else 
  {
    py_obj pyObj = PyObject_Str(pObj);
    if (!pyObj.isNull())
      return toString(pyObj);
    PyErr_Clear();
    
    pyObj = PyObject_Unicode(pObj);
    if (!pyObj.isNull())
      return toString(pyObj);

    PyErr_Clear();
    pyObj = PyObject_Repr(pObj);
    if (!pyObj.isNull())
      return toString(pyObj);
  }
  return bstr_t();
}

py_obj utils::call_member0(PyObject* pObj, const char* member)
{  
  if (PyObject_HasAttrString(pObj, member))
    return PyObject_CallMethod(pObj, (char*)member, "", NULL);    
  return (PyObject*)NULL;
}

PyObject* utils::create_object(PyTypeObject* type, void* ptrHost)
{
  PythonExecuteWaitNoCursor WaitHere;

  py_obj d = PyDict_New();
  if (d.isNull())
    return NULL;

  if (PyDict_SetItemString(d, type->tp_name, (PyObject*)type) != 0)
    return NULL;

  char buff[128];
  wsprintfA(buff, "obj=%s(%i)", type->tp_name, (DWORD_PTR)ptrHost);
  py_obj ret = PyRun_String(buff, Py_single_input/*Py_file_input*/, d, d);

  if (!ret)
    return 0;

  PyObject* result = PyDict_GetItemString(d, "obj");
  Py_XINCREF(result);
  return result;
}

void utils::XYTOMapXY(long x, long y, double& mapx, double& mapy)
{
  IMxApplicationPtr ipApp(CLSID_AppRef);
  IAppDisplayPtr ipDisplay;
  IDisplayTransformationPtr ipTransform;
  IPointPtr ipPoint;
  if (ipApp)
    ipApp->get_Display(&ipDisplay);
  if (ipDisplay)
    ipDisplay->get_DisplayTransformation(&ipTransform);
  if (ipTransform)
    ipTransform->ToMapPoint(x, y, &ipPoint);
  if (ipPoint)
  {
    ipPoint->get_X(&mapx);
    ipPoint->get_Y(&mapy);
  }
  else
  {
    mapx = (double)x;
    mapy = (double)y;
  }
}

void utils::GetPythonWindow(IApplication* pApp, IGPCommandWindowAccessImpl **ppPyWin)
{
  if (!ppPyWin)
    return;

  *ppPyWin = 0;

  IGPCommandWindowAccessImplPtr ipWindow;
  IDockableWindowManagerPtr ipDockableWindowManager(CLSID_AppRef);
  IDockableWindowPtr ipDockWindow;

  if (ipDockableWindowManager)
  {
    IUIDPtr ipUID(CLSID_UID);
    ((IUIDAdminPtr)ipUID)->SetID((GUID*)&CLSID_GPCommandWindow, 0);
    ipDockableWindowManager->GetDockableWindow(ipUID, &ipDockWindow);
    //ipDockWindow->
  }

  ipWindow = ipDockWindow;

  if (ipWindow)
  {
    ipWindow->AddRef();
    *ppPyWin = ipWindow;
  }
  else
  {
    ipWindow.CreateInstance(CLSID_GPCommandWindow);
    if (ipWindow)
      ipWindow->AddRef();
    *ppPyWin = ipWindow;
  }
}

void destroy_unknown(void *vUnk)
{
  if (vUnk)
  {
    ((IUnknown*)vUnk)->Release();
  }
}

static PyObject* WrapGPObject(void* pObject, char* objectType)
{
  py_obj ap(PyImport_ImportModuleNoBlock("arcpy")),
         co(0);

  PyErr_Clear();

  if (ap)
  {
    co = PyObject_GetAttrString(ap, "CreateObject");
  }

  if (co)
  {
    ((IUnknown*)pObject)->AddRef();
    py_obj object_pointer(PyCObject_FromVoidPtr(pObject, destroy_unknown));
    return PyObject_CallFunction(co, "sO", objectType, (PyObject*)object_pointer);
  }
  else
  {
    PyErr_Print();
    return 0;
  }
}

PyObject* utils::AsPythonGeometry(IGeometry* pGeometry)
{
  if (!pGeometry)
  {
    Py_RETURN_NONE;
  }

  IEnvelopePtr ipEnvelope(pGeometry);

  void* geom(pGeometry);
  return WrapGPObject(geom, (ipEnvelope) ? "Extent" : "Geometry");
}

PyObject* utils::AsPythonDataFrame(IMap* pMap)
{
  if (!pMap)
  {
    Py_RETURN_NONE;
  }

  return WrapGPObject((void*)(pMap), "DataFrame");
}

PyObject* utils::AsPythonLayer(ILayer* pLayer)
{
  if (!pLayer)
  {
    Py_RETURN_NONE;
  }

  return WrapGPObject((void*)(pLayer), "Layer");
}

PyObject* utils::VariantAsKnownPyObject(VARIANT var)
{

  if ((var.vt == VT_BSTR) ||
      (var.vt == (VT_BSTR | VT_BYREF)))
  {
    BSTR return_string((var.vt & VT_BYREF) ? *(var.pbstrVal) : var.bstrVal);
    return PyUnicode_FromWideChar(return_string, ::SysStringLen(return_string));
  }

  IUnknownPtr ipUnk;
  if (var.vt == VT_UNKNOWN)
  {
    ipUnk = var.punkVal;
  }
  else if (var.vt == (VT_UNKNOWN | VT_BYREF))
  {
    ipUnk = *(var.ppunkVal);
  }

  if (ipUnk)
  {
    ILayerPtr ipLayer(ipUnk);
    IMapPtr ipMap(ipUnk);
    IGeometryPtr ipGeom(ipUnk);

    if (ipLayer)
    {
      return AsPythonLayer(ipLayer);
    }
    else if (ipMap)
    {
      return AsPythonDataFrame(ipMap);
    }
    else if (ipGeom)
    {
      return AsPythonGeometry(ipGeom);
    }
  }

  Py_RETURN_NONE;
}