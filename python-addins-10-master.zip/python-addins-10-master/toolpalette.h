/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once

#include "button.h"
#include <vector>

class ATL_NO_VTABLE wrap_toolpalette :
	public CComObjectRootEx<CComSingleThreadModel>,
  public command_base<wrap_toolpalette>,
  public IToolPalette
{
 public:
  std::vector<bstr_t> m_items;
  long m_columncount;
  bool m_ismenustyle;
  bool m_cantearoff;

  wrap_toolpalette() : 
    m_columncount(2),
    m_cantearoff(false),
    m_ismenustyle(true)
	{
	}
  ~wrap_toolpalette()
  {
  }

  //IToolPalette
  STDMETHOD(get_PaletteItemCount) (long * numItems) { *numItems = (long)m_items.size(); return S_OK; }
  STDMETHOD(get_PaletteItem) (long pos, BSTR * ID)
  {
    size_t idx = (size_t)pos;
    if (idx >= m_items.size())
      return E_FAIL;

    const bstr_t& it = m_items[idx];
    *ID = it.copy();
    return S_OK;
  }
  STDMETHOD(get_PaletteColumns) (long * columns)
  {
    *columns = m_columncount;
    return S_OK;
  }
  STDMETHOD(get_MenuStyle) (VARIANT_BOOL * menu)
  {
    *menu = (m_ismenustyle) ? VARIANT_TRUE : VARIANT_FALSE;  
    return S_OK;
  }
  STDMETHOD(get_TearOff) (VARIANT_BOOL * TearOff)
  {
    *TearOff = (m_cantearoff) ? VARIANT_TRUE : VARIANT_FALSE; 
    return S_OK;
  }
  
BEGIN_COM_MAP(wrap_toolpalette)
	COM_INTERFACE_ENTRY(ICommand)
  COM_INTERFACE_ENTRY(IToolPalette)
END_COM_MAP()
};