/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once
#include <vector>

class ATL_NO_VTABLE wrap_toolbar :
	public CComObjectRootEx<CComSingleThreadModel>,
  public IToolBarDef
{
public:

  bstr_t m_id;
  bstr_t m_caption;
  struct def
  {
    bstr_t id;
    bool group;
    long sub;
  };
  std::vector<def> m_items;
  STDMETHOD(get_ItemCount)(long * numItems) { *numItems = (long)m_items.size(); return S_OK; }
  STDMETHOD(GetItemInfo)(long pos, IItemDef * itemDef)
  {
    size_t idx = (size_t)pos;
    if (idx >= m_items.size())
      return E_FAIL;

    const def& it = m_items[idx];
    itemDef->put_Group(it.group ? VARIANT_TRUE : VARIANT_FALSE);
    itemDef->put_ID(it.id);
    itemDef->put_SubType(it.sub);
    return S_OK;
  }

  STDMETHOD(get_Name)(BSTR * Name){ *Name = m_id.copy(); return S_OK; }
  STDMETHOD(get_Caption)(BSTR * Name){ *Name = m_caption.copy(); return S_OK; }


BEGIN_COM_MAP(wrap_toolbar)
	COM_INTERFACE_ENTRY(IToolBarDef)
END_COM_MAP()

	//DECLARE_PROTECT_FINAL_CONSTRUCT()
public:
};
