/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once

#include "utils.h"

template <DWORD _flags = 0>
class flag_Traits
{
public:
  enum { tp_flags = _flags };	
};

typedef flag_Traits<Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE | Py_TPFLAGS_HAVE_GC> defaultFlags;
typedef flag_Traits<0> end_Traits;

template <class T, class flag_Traits>
struct type_base
{
  PyObject_HEAD  
  static PyTypeObject pyType;
  static const char* type_name;
  struct _mem_obj
  {
    BYTE buff[sizeof(T)];
    long deleted;
  };

  static bool pre_init_type()
  {
    pyType.tp_basicsize = sizeof(_mem_obj);
    pyType.tp_name = type_name;
    pyType.tp_new = &T::tp_new;
    pyType.ob_type = &PyType_Type;
    pyType.tp_dealloc = &T::tp_dealloc;
    pyType.tp_traverse = &T::tp_traverse;
    pyType.tp_clear = &T::tp_clear;
    pyType.tp_flags = flag_Traits::tp_flags;//Py_TPFLAGS_DEFAULT|Py_TPFLAGS_BASETYPE;
    return PyType_Ready(&pyType) >= 0;
  }

protected:
  

  static PyObject* tp_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
  {
    _mem_obj* self = NULL;
    _ASSERT(type == &T::pyType);
    _ASSERT(type->tp_name == type_name);
    if (pyType.tp_flags & Py_TPFLAGS_HAVE_GC)
      self = PyObject_GC_New(_mem_obj, type);
    else
      self = PyObject_New(_mem_obj, type);

    if (self != NULL) 
    {      
      if (pyType.tp_flags & Py_TPFLAGS_HAVE_GC)
        PyObject_GC_Track(self);

      new (self) T(args);//, kwds);
      self->deleted = 'not';
      if (PyErr_Occurred()) // if constructor generate error delete object
      {
        type->tp_dealloc((PyObject*)self);
        //error already set in constructor
        return NULL;
      }      
      return (PyObject*)self; 
    }
    return PyErr_NoMemory();
  } 
  static int tp_traverse(PyObject *self, visitproc, void *){  return 0; }
  static int tp_clear(PyObject *self) 
  { 
    _mem_obj* o = (_mem_obj*)self;

    if (o->deleted == 'not')
    {
      reinterpret_cast<T*>(self)->~T();
      o->deleted = 'yes';
    }
    return 0; 
  }

  static void tp_dealloc(PyObject *self)
  {
    _mem_obj* o = (_mem_obj*)self;
    if (o->deleted == 'not')
    {
      reinterpret_cast<T*>(self)->~T();
      o->deleted = 'yes';
    }

    if (pyType.tp_flags & Py_TPFLAGS_HAVE_GC)
    {
      PyObject_GC_UnTrack((PyObject *) self);      
      PyObject_GC_Del(self);
    }
    else
    {      
      PyObject_Del(self);
    }    
  }  

public:
  typedef type_base<T, flag_Traits> type_base_type; 

protected:
  explicit type_base(){}
};

template <class T, class flag_Traits> PyTypeObject type_base<T, flag_Traits>::pyType = {PyObject_HEAD_INIT(NULL) 0};


//----------------------------------------------------------------------------
// extra 

#define IMPLEMENT_EMPTY_CALL_MAP(x) public:\
  PyObject* processCall(const char* name_, PyObject *args, bool& h) \
	{ h = false; return PyErr_Format(PyExc_AttributeError, "Invalid attribute %s", name_); }

#define IMPLEMENT_EMPTY_ATTR_MAP(x) public:\
  PyObject* processAttr(const char* name_, PyObject* in, bool& h) { h = false; return NULL; }

template <class TBase, class H>
class proxy : public type_base<proxy<TBase, H>, flag_Traits<defaultFlags::tp_flags /*| Py_TPFLAGS_HAVE_GC*/> > 
{  
public:
  typedef TBase _TBase;
  typedef proxy<TBase, H> proxy_type;
  typedef H* hook_type;
  
  proxy(PyObject *args) : m_pHook(NULL)
  { 
    //OutputDebugStringA(" proxy():");
    //OutputDebugStringA(type_name);

    long int_ptr = 0;
    if (PyArg_ParseTuple(args, "l", &int_ptr))
    {
      m_pHook = (hook_type)int_ptr;
      if (m_pHook)
        m_pHook->AddRef();
    }      
  }
  ~proxy()
  {
    //OutputDebugStringA(" ~proxy():");
    //OutputDebugStringA(type_name);

    if (m_pHook)
      m_pHook->Release();
    m_pHook = NULL;
  }

  static bool pre_init_type()
  {
    pyType.tp_call = &s_call;
    pyType.tp_getattro = &s_getattro;
    pyType.tp_setattro = &s_setattro;
    pyType.tp_compare = &s_compare;
    return type_base::pre_init_type();
  }
  
  static PyObject* s_call(PyObject *self, PyObject *args, PyObject *kw)
  {
    return ((proxy_type*)self)->call(args, kw);
  }
  static PyObject* s_getattro(PyObject *self, PyObject *arg)
  {
    return ((proxy_type*)self)->getattro(arg);
  }
  static int s_setattro(PyObject *self, PyObject *nm, PyObject *arg)
  {
    return ((proxy_type*)self)->setattro(nm, arg);
  }
  
  static int s_compare(PyObject *self, PyObject *obj)
  {
    if (!PyObject_TypeCheck(obj, &pyType))
      return 0;
    if (((proxy_type*)self)->m_pHook == ((proxy_type*)obj)->m_pHook)
      return 1;
    return 0;
  }
  
  hook_type m_pHook;
protected:
  
  //type definition
private:
  char m_call[128];
  
  PyObject *call(PyObject *args, PyObject *kw)
  {    
    bool processed = false;
    PyObject* ret = ((_TBase*)this)->processCall(m_call, args, processed);
    if (!processed)
    {
      OutputDebugStringA("\n*** Py Proxy - WARNING get attr: ");
      OutputDebugStringA(m_call);
      OutputDebugStringA(" not prosessed");
    }
    m_call[0] = 0;
    return ret;
  }

  PyObject *getattro(PyObject *arg)
  {
    const char* name = PyString_AsString(arg);

    bool processed = false;
    PyObject* ret = ((_TBase*)this)->processAttr(name, NULL, processed);
    if (processed)
      return ret;
    else
    {
      strcpy_s(m_call, name);
      Py_INCREF(this);
      return (PyObject*)this;
    }
  }
  
  int setattro(PyObject *nm, PyObject *arg)
  {
    const char* name = PyString_AsString(nm);

    bool processed = false;
    PyObject* ret = ((_TBase*)this)->processAttr(name, arg, processed);
    Py_XDECREF(ret);

    if (processed)
      return 0;
    if (!processed)
    {
      OutputDebugStringA("\n*** Py Proxy - WARNING set attr: ");
      OutputDebugStringA(name);
      OutputDebugStringA(" not prosessed");
      PyErr_Format(PyExc_AttributeError, "Invalid attribute %s", name);
    }
    return -1;
  }
};

