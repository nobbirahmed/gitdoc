/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#include "stdafx.h"
#include "proxy_impls.h"
#include <vector>

const char* proxy_app::proxy_type::type_base_type::type_name = "esri_Application";
const char* proxy_doc::proxy_type::type_base_type::type_name = "esri_Document";
const char* proxy_map::proxy_type::type_base_type::type_name = "esri_Map";
const char* proxy_layer::proxy_type::type_base_type::type_name = "esri_Layer";

void register_types()
{
  proxy_app::pre_init_type();
  //ATLASSERT(PyDict_SetItemString(d, proxy_app::type_name, (PyObject*)&proxy_app::pyType)==0);

  proxy_doc::pre_init_type();
  //ATLASSERT(PyDict_SetItemString(d, proxy_doc::type_name, (PyObject*)&proxy_doc::pyType)==0);

  proxy_map::pre_init_type();
  //ATLASSERT(PyDict_SetItemString(d, proxy_map::type_name, (PyObject*)&proxy_map::pyType)==0);
  proxy_layer::pre_init_type();     
}

////   APP
PyObject* proxy_app::getDoc()
{
  IDocumentPtr ipDoc;
  m_pHook->get_Document(&ipDoc);
  return utils::create_object(&proxy_doc::pyType, (IDocument*)ipDoc);
}

PyObject* proxy_app::newDocument(const bstr_t &str)
{
  HRESULT hr = m_pHook->NewDocument(VARIANT_FALSE, NULL);
  if (hr == S_OK)
    Py_RETURN_TRUE;
  else
    Py_RETURN_FALSE;
}

/////////  DOC

PyObject* proxy_doc::getTitle()
{
  bstr_t name;
  m_pHook->get_Title(at(name));
  return PyUnicode_FromWideChar(name, name.length());
}

PyObject* proxy_doc::getMap()
{
  IMapPtr ipMap;
  IMxDocumentPtr(m_pHook)->get_FocusMap(&ipMap);
  
  return utils::create_object(&proxy_map::pyType, (IMap*)ipMap);
}

//////////////  MAP
PyObject* proxy_map::attrName(PyObject* in)
{
  bstr_t name;
  if (in == NULL) //get
  {
    m_pHook->get_Name(at(name));
    return PyUnicode_FromWideChar(name, name.length());
  }
  m_pHook->put_Name(utils::toString(in));
  Py_RETURN_NONE;
}
/* same as GET_ATTR_DIRECT_LONG(LayerCount) 
PyObject* proxy_map::layerCount()
{
  long count = 0;
  m_pHook->get_LayerCount(&count);
  return PyLong_FromLong(count);
}*/

PyObject* proxy_map::getLayer(PyObject* args)
{
  PyObject* a1 = PyTuple_GET_ITEM(args, 0);
  
  py_obj first = PyNumber_Long(a1);
  if (first.isNull())
    return NULL;

  long idx = PyLong_AsLong(first);
  ILayerPtr ipLayer;
  m_pHook->get_Layer(idx, &ipLayer);
  if (ipLayer == NULL)
    return NULL;
  return utils::create_object(&proxy_layer::pyType, (ILayer*)ipLayer);
}

PyObject* proxy_map::getLayers()
{
  IEnumLayerPtr ipLayers;
  m_pHook->get_Layers(NULL, VARIANT_TRUE, &ipLayers);
  if (ipLayers == NULL)
    return NULL;
  
  std::vector<ILayer*> all;
  ILayerPtr ipLayer;
  while(ipLayers->Next(&ipLayer) == S_OK)
    all.push_back(ipLayer);
  PyObject* ret = PyTuple_New(all.size());
  for (size_t i = 0; i < all.size(); i++)
    PyTuple_SET_ITEM(ret, i, utils::create_object(&proxy_layer::pyType, all[i]));
  return ret;
}


//////////////  Layer
PyObject* proxy_layer::attrName(PyObject* in)
{
  bstr_t name;
  if (in == NULL) //get
  {
    m_pHook->get_Name(at(name));
    return PyUnicode_FromWideChar(name, name.length());
  }
  m_pHook->put_Name(utils::toString(in));
  Py_RETURN_NONE;
}
