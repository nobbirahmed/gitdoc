/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#include "stdafx.h"
#include "utils.h"
#include "PythonExecuteWait.h"

// Python object that wraps sys.stdout or sys.stderr and relays all
// output along to Python Window in app.

typedef struct StreamWrapperObject
{
    PyObject_HEAD
    bool m_isStderr;
    bool m_wroteOut;
    PyObject* m_pPyObjectPassthrough;
    IGPCommandWindowAccessImpl* m_pPyWindow;
} StreamWrapperObject;

static void StreamWrapperObject_dealloc(StreamWrapperObject *self)
{
  Py_XDECREF(self->m_pPyObjectPassthrough);
  if (self->m_pPyWindow)
    self->m_pPyWindow->Release();
  PyObject_DEL(self);
}

// Passthrough setattr
static int StreamWrapperObject_setattr(StreamWrapperObject* self, char* attr, PyObject* value)
{
  return PyObject_SetAttrString(self->m_pPyObjectPassthrough, attr, value);
}

// Intermediary .write method
static PyObject* StreamWrapperObject_write(StreamWrapperObject* self, PyObject* args, PyObject* keywords)
{
  // Do our thing, intercept text and output to window
  if (PyTuple_Check(args) && self->m_pPyWindow)
  {
    for (Py_ssize_t arg_index(0); arg_index < PyTuple_Size(args); ++arg_index)
    {
      _bstr_t string_to_print = utils::toString(PyTuple_GET_ITEM(args, arg_index));

      if (self->m_isStderr)
        self->m_pPyWindow->WriteStderr(string_to_print, (self->m_wroteOut) ? VARIANT_FALSE : VARIANT_TRUE);
      else
        self->m_pPyWindow->WriteStdout(string_to_print, (self->m_wroteOut) ? VARIANT_FALSE : VARIANT_TRUE);
      if (string_to_print.length())
        self->m_wroteOut = true;
    }
  }

  // Then do the standard passthough thing
  PyObject *write_method(PyObject_GetAttrString(self->m_pPyObjectPassthrough, "write"));
  if (write_method)
  {
    PyObject* return_value = PyObject_Call(write_method, args, keywords);
    Py_DECREF(write_method);

    if (return_value)
      return return_value;
    else
    { // Swallow error just in case it's something dumb like a
      // UnicodeEncodeError -- it already successfully went to
      // the Python window, so we don't want to get a traceback
      // for the passthrough terminal's encoding being wrong
      PyErr_Clear();
      Py_RETURN_NONE;
    }
  }
  else
  {
    PyErr_Clear();
    Py_RETURN_NONE;
  }
}

static PyMethodDef StreamWrapperObject_methods[] = {
  {"write",     (PyCFunction)StreamWrapperObject_write, METH_VARARGS|METH_KEYWORDS, NULL},
  {NULL, NULL, NULL, NULL}
};

// Passthrough getattr (with check for .write)
static PyObject* StreamWrapperObject_getattr(StreamWrapperObject* self, char* attr)
{
  // Look for overridden .write method
  PyObject* found_method = Py_FindMethod(StreamWrapperObject_methods, (PyObject*)self, attr);
  if (found_method)
    return found_method;
  else if (PyErr_Occurred())
    PyErr_Clear();

  return PyObject_GetAttrString(self->m_pPyObjectPassthrough, attr);
}

static PyTypeObject StreamWrapperObject_Type = {
    PyObject_HEAD_INIT(&PyType_Type)
    0,                                        /*ob_size*/
    "Wrapped sys.stdout/stderr object",       /*tp_name*/
    sizeof(StreamWrapperObject),              /*tp_basicsize*/
    0,                                        /*tp_itemsize*/
    (destructor)StreamWrapperObject_dealloc,  /*tp_dealloc*/
    0,                                        /*tp_print*/
    (getattrfunc)StreamWrapperObject_getattr, /*tp_getattr*/
    (setattrfunc)StreamWrapperObject_setattr, /*tp_setattr*/
    0,                                        /*tp_compare*/
    0,                                        /*tp_repr*/
    0,                                        /*tp_as_number*/
	  0,                                	      /*tp_as_sequence*/
	  0,                                		    /*tp_as_mapping*/
	  0,                                        /*tp_hash*/
	  0,			                                  /*tp_call*/
	  0,     			                              /*tp_str*/
	  0,		     	                              /*tp_getattro*/
	  0,			                                  /*tp_setattro*/
	  0,		                               	    /*tp_as_buffer*/
	  Py_TPFLAGS_DEFAULT,                  	    /*tp_flags*/
};

PythonExecuteWaitNoCursor::PythonExecuteWaitNoCursor()
{
  m_ipPythonWindow.CreateInstance(CLSID_GPCommandWindow);

  WrapOutputStreams();
}

PythonExecuteWaitNoCursor::~PythonExecuteWaitNoCursor()
{
  PumpError();

  // New prompt string if needed
  if (((StreamWrapperObject*)m_pNewStdout)->m_wroteOut ||
      ((StreamWrapperObject*)m_pNewStderr)->m_wroteOut)
    m_ipPythonWindow->Reprompt();

  // Restore old stdout/stderr
  PySys_SetObject("stdout", m_pOldStdout);
  PySys_SetObject("stderr", m_pOldStderr);
  Py_XDECREF(m_pNewStdout);
  Py_XDECREF(m_pNewStderr);
  Py_XDECREF(m_pOldStdout);
  Py_XDECREF(m_pOldStderr);
}

void PythonExecuteWaitNoCursor::PumpError()
{
  if (PyErr_Occurred())
  {
    PyObject *pType(0),
             *pValue(0),
             *pTraceback(0);
    PyErr_Fetch(&pType, &pValue, &pTraceback);
    PyErr_NormalizeException(&pType, &pValue, &pTraceback);

    py_obj etype(pType),
           evalue(pValue),
           etraceback(pTraceback);

    // CR181179
    if (PyErr_GivenExceptionMatches(pType, PyExc_IOError) &&
        pValue)
    {
      _bstr_t string_value(utils::toString(pValue));
      if (_tcsstr((wchar_t*)string_value, _T("Bad file descriptor")) != 0)
      {
        PyErr_Clear();
        return;
      }
    }

    if (!pTraceback)
      pTraceback = Py_None;

    py_obj tb(PyImport_ImportModule("traceback")),
           print_exc(NULL);
    if (tb)
      print_exc = PyObject_GetAttrString(tb, "print_exception");
    if (print_exc)
    {
      py_obj err_call(PyObject_CallFunction(print_exc, "OOO", pType, pValue, pTraceback));
      PyErr_Clear();
    }
  }
}


void PythonExecuteWaitNoCursor::WrapOutputStreams()
{
  // Cache old stdout/stderr
  m_pOldStdout = PySys_GetObject("stdout");
  m_pOldStderr = PySys_GetObject("stderr");
  StreamWrapperObject *newstdout(0),
                      *newstderr(0);

  if (PyObject_IsInstance(m_pOldStdout, (PyObject*)&StreamWrapperObject_Type))
  {
    newstdout = (StreamWrapperObject*)m_pOldStdout; // Already wrapped?
    Py_INCREF(newstdout);
  }
  else
  {
    // Create new stdout wrapper
    newstdout = PyObject_New(StreamWrapperObject, &StreamWrapperObject_Type);
    newstdout->m_isStderr = false;
    newstdout->m_wroteOut = false;
    newstdout->m_pPyObjectPassthrough = m_pOldStdout;
    Py_XINCREF(newstdout->m_pPyObjectPassthrough);
    newstdout->m_pPyWindow = m_ipPythonWindow;
    if (newstdout->m_pPyWindow)
      newstdout->m_pPyWindow->AddRef();
  }

  if (PyObject_IsInstance(m_pOldStderr, (PyObject*)&StreamWrapperObject_Type))
  {
    newstderr = (StreamWrapperObject*)m_pOldStderr; // Already wrapped?
    Py_INCREF(newstderr);
  }
  else
  {
    // Create new stderr wrapper
    newstderr = PyObject_New(StreamWrapperObject, &StreamWrapperObject_Type);
    newstderr->m_isStderr = true;
    newstderr->m_wroteOut = false;
    newstderr->m_pPyObjectPassthrough = m_pOldStderr;
    Py_XINCREF(newstderr->m_pPyObjectPassthrough);
    newstderr->m_pPyWindow = m_ipPythonWindow;
    if (newstderr->m_pPyWindow)
      newstderr->m_pPyWindow->AddRef();
  }

  m_pNewStdout = (PyObject*)newstdout;
  m_pNewStderr = (PyObject*)newstderr;

  // Retain a reference
  Py_XINCREF(m_pOldStdout);
  Py_XINCREF(m_pOldStderr);

  // Swap out with new
  PySys_SetObject("stdout", m_pNewStdout);
  PySys_SetObject("stderr", m_pNewStderr);
}