/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once
#include "utils.h"
#include "PythonExecuteWait.h"

class ATL_NO_VTABLE wrap_multiitem :
  public control,
	public CComObjectRootEx<CComSingleThreadModel>,
  public IMultiItem,
  public IMultiItemEx,
  public IMultiItemSeparator,
  public IComponentTip
{
public:

  // IMultiItem
  STDMETHOD(get_Name)(BSTR *Name) { *Name = m_id.copy(); return E_NOTIMPL; }
  STDMETHOD(get_Caption)(BSTR * Name) { return E_NOTIMPL; }
  STDMETHOD(get_Message)(BSTR * Message) { return E_NOTIMPL; }
  STDMETHOD(get_HelpFile)(BSTR * HelpFile) { *HelpFile = 0; return S_OK; }
  STDMETHOD(get_HelpContextID)(long * ID) { *ID = 0; return S_OK; }
  STDMETHOD(OnPopup)(IDispatch * Hook, long * ItemCount)
  {
    py_obj items = PyObject_GetAttrString(m_pyObj, "items");
    if (items && PySequence_Check(items))
      *ItemCount = PySequence_Length(items);
    else
      *ItemCount = 0;
    return S_OK;
  }
  STDMETHOD(get_ItemCaption)(long index, BSTR * itemName)
  {
    py_obj items = PyObject_GetAttrString(m_pyObj, "items");
    *itemName = 0;
    if (items && PySequence_Check(items))
    {
      Py_ssize_t length = PySequence_Length(items);
      if (index >= length || index < 0)
        return E_INVALIDARG;
      py_obj item = PySequence_GetItem(items, index);
      *itemName = utils::toString(item);
      return S_OK;
    }
    else
      return E_FAIL;
  }
  STDMETHOD(get_ItemBitmap)(long index, ESRI_OLE_HANDLE * Bitmap) { *Bitmap = 0; return S_OK; }
  STDMETHOD(OnItemClick)(long index)
  {
    PythonExecuteWait WaitHere;
    py_obj items = PyObject_GetAttrString(m_pyObj, "items");
    if (items && PySequence_Check(items))
    {
      Py_ssize_t length = PySequence_Length(items);
      if (index >= length || index < 0)
        return E_INVALIDARG;
      if (PyObject_HasAttrString(m_pyObj, "onItemClick"))
      {
        py_obj item = PySequence_GetItem(items, index);
        py_obj return_val = PyObject_CallMethod(m_pyObj, "onItemClick", "O", (PyObject*)item);
      }
      WaitHere.PumpError();
      if (PyObject_HasAttrString(m_pyObj, "onItemClickByIndex"))
      {
        py_obj return_val = PyObject_CallMethod(m_pyObj, "onItemClickByIndex", "l", index);
      }
      return S_OK;
    }
    else
      return E_FAIL;
  }
  STDMETHOD(get_ItemChecked)(long index, VARIANT_BOOL * bChecked) { *bChecked = VARIANT_FALSE; return S_OK; }
  STDMETHOD(get_ItemEnabled)(long index, VARIANT_BOOL * bEnabled) { *bEnabled = VARIANT_FALSE; return S_OK; }
  // IMultiItemEx
  STDMETHOD(get_ItemMessage)(long index, BSTR * Message) { *Message = 0; return S_OK; }
  STDMETHOD(get_ItemHelpFile)(long index, BSTR * HelpFile) { *HelpFile = 0; return S_OK; }
  STDMETHOD(get_ItemHelpContextID)(long index, long * ID) { *ID = 0; return S_OK; }
  // IMultiItemSeparator
  STDMETHOD(get_Separator) (long index, VARIANT_BOOL * bSeparator)
  {
    bool separator = false;
    *bSeparator = separator ? VARIANT_TRUE : VARIANT_FALSE;
    return S_OK;
  }
  // IComponentTip
  STDMETHOD(get_Heading)( BSTR * Heading ) { *Heading = 0; return S_OK; }
  STDMETHOD(get_Tip)( BSTR * Tip ) { *Tip = 0; return S_OK; }
  STDMETHOD(get_Image)( ESRI_OLE_HANDLE * Image ) { *Image = 0; return S_OK; }

BEGIN_COM_MAP(wrap_multiitem)
  COM_INTERFACE_ENTRY(IMultiItem)
  COM_INTERFACE_ENTRY(IMultiItemEx)
  COM_INTERFACE_ENTRY(IMultiItemSeparator)
  COM_INTERFACE_ENTRY(IComponentTip)
END_COM_MAP()
};