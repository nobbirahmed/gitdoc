/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once
//#include "proxy.h"
#include "constants.h"
#include "utils.h"
#include "PythonExecuteWait.h"

//bool create_and_add_app(IApplication* pApp, PyObject* obj);

template<class TBase>
class ATL_NO_VTABLE command_base : 
  public control,
  public ICommand
{
protected:
  command_base() : m_bmp(NULL){}
  ~command_base() { ::DeleteObject(m_bmp); }

  bstr_t m_tips;
  bstr_t m_category;
  bstr_t m_caption;
  bstr_t m_msg;
  bstr_t m_hinttext;
  HBITMAP m_bmp;
public:

  STDMETHOD(get_Enabled)(VARIANT_BOOL* pEnabled)
  {
    TBase* base = static_cast<TBase*>(this);
    bool b = false;    
    if (utils::attr(base->m_pyObj, "enabled", b))
    {
      *pEnabled = b ? VARIANT_TRUE : VARIANT_FALSE;
      return S_OK;
    }
    *pEnabled = VARIANT_TRUE;
    return S_OK;
  }

  STDMETHOD(get_Checked)(VARIANT_BOOL* pChecked)
  {
    TBase* base = static_cast<TBase*>(this);
    bool b = false;
    if (utils::attr(base->m_pyObj, "checked", b))
    {
      *pChecked = b ? VARIANT_TRUE : VARIANT_FALSE;
      return S_OK;
    }  
    return S_FALSE;
  }

  STDMETHOD(get_Bitmap)(ESRI_OLE_HANDLE* pBitmap){ *pBitmap = (ESRI_OLE_HANDLE)m_bmp; return S_OK; }
  STDMETHOD(get_Tooltip)(BSTR* pText)
  {
    TBase* base = static_cast<TBase*>(this);
    bstr_t tips;
    if (utils::attr(base->m_pyObj, "tooltip", tips))
      *pText = tips.copy();
    else
      *pText = m_tips.copy();

    return S_OK;
  }

  STDMETHOD(get_Name)(BSTR* pText) 
  { 
    TBase* base = static_cast<TBase*>(this);
    *pText = base->m_id.copy(); 
    return S_OK; 
  }
  STDMETHOD(get_ShortCutKey)(BSTR* pText){ return S_OK; }
  STDMETHOD(get_Message)(BSTR* pText){ *pText = m_msg.copy(); return S_OK; }

  STDMETHOD(get_HelpFile)(BSTR* pText){ return S_OK; }
  STDMETHOD(get_HelpContextID)(long* pText){ return S_OK; }
  STDMETHOD(get_Category)(BSTR* pText){ *pText = m_category.copy(); return S_OK; }
  STDMETHOD(OnCreate)(IDispatch* pHook)
  {        
    TBase* base = static_cast<TBase*>(this);
    IApplicationPtr ipApp(pHook);
    
    if (base->m_pyObj)
    {
      PythonExecuteWait RunWrap;

      py_obj ret = utils::call_member0(base->m_pyObj, s_onCreate);
    }
    return S_OK;
  }

  STDMETHOD(get_Caption)(BSTR* pText){ *pText = m_caption.copy(); return S_OK; }

  STDMETHOD(OnClick)()
  {
    TBase* base = static_cast<TBase*>(this);
    if (base->m_pyObj)
    {
      PythonExecuteWait RunWrap;

      py_obj ret = utils::call_member0(base->m_pyObj, s_onClick);
    }
    return S_OK;
  }
  
  static HBITMAP createBitmap(IStream* pStream)
  {
    if (!pStream)
      return NULL;
    
    HBITMAP hb = NULL;
    std::auto_ptr<Gdiplus::Bitmap> bmp(Gdiplus::Bitmap::FromStream(pStream, FALSE));
    if (bmp.get())
      bmp->GetHBITMAP(Gdiplus::Color::HotPink, &hb);
    return hb;
  }

  void readConfig(IAddInRecord* pRecord)
  {
    ATLASSERT(pRecord);
    if (!pRecord)
      return;

    pRecord->ReadString(L"message", at(m_msg));
    pRecord->ReadString(L"caption", at(m_caption));
    pRecord->ReadString(L"tip", at(m_tips));  
    pRecord->ReadString(L"category", at(m_category));
    pRecord->ReadString(L"hintText", at(m_hinttext));
    IStreamPtr ipStream;
    if (pRecord->ReadStream(L"image", &ipStream) == S_OK)
      m_bmp = createBitmap(ipStream);
  }
};

class ATL_NO_VTABLE wrap_button :
	public CComObjectRootEx<CComSingleThreadModel>,
  public command_base<wrap_button>
{
  //friend class command_base<wrap_button>;
public:
  
BEGIN_COM_MAP(wrap_button)
	COM_INTERFACE_ENTRY(ICommand)
END_COM_MAP()
};