/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once
#include "utils.h"
#include <vector>

class ATL_NO_VTABLE wrap_menu:
	public CComObjectRootEx<CComSingleThreadModel>,
  public IMenuDef,
  public IRootLevelMenu,
  public IShortcutMenu
{
public:

  bool m_isShortcut;
  bool m_isTopLevel;
  bstr_t m_id;
  bstr_t m_caption;
  struct def
  {
    bstr_t id;
    bool group;
    long sub;
  };
  std::vector<def> m_items;

  wrap_menu() : 
    m_isShortcut(false),
    m_isTopLevel(false)
	{
	}
  ~wrap_menu()
  {
  }

  void readConfig(IAddInRecord* pRecord)
  {
    ATLASSERT(pRecord);
    if (!pRecord)
      return;

    VARIANT_BOOL isroot = VARIANT_FALSE,
                 isshortcut = VARIANT_FALSE;

    pRecord->ReadString(L"caption", at(m_caption));
    if (SUCCEEDED(pRecord->ReadBool(L"isRootMenu", &isroot)))
      m_isTopLevel = (isroot == VARIANT_TRUE) ? true : false;
    if (SUCCEEDED(pRecord->ReadBool(L"isShortcutMenu", &isshortcut)))
      m_isShortcut = (isshortcut == VARIANT_TRUE) ? true : false;
  }

  //IMenuDef
  STDMETHOD(get_ItemCount) (long * numItems )
  {
    *numItems = m_items.size();
    return S_OK;
  }
  STDMETHOD(GetItemInfo) (long pos, IItemDef * itemDef )
  {
    if (pos < (unsigned long)0 || (unsigned long)pos >= m_items.size())
      return E_FAIL;
    const def& it = m_items[pos];
    itemDef->put_Group(it.group ? VARIANT_TRUE : VARIANT_FALSE);
    itemDef->put_ID(it.id);
    itemDef->put_SubType(it.sub);
    return S_OK;
  }
  STDMETHOD(get_Name)(BSTR *pName) 
  { 
    if (pName)
      *pName = m_id.copy(); 
    return S_OK; 
  }
  STDMETHOD(get_Caption) (BSTR * Name )
  {
    *Name = m_caption.copy();
    return S_OK;
  }

BEGIN_COM_MAP(wrap_menu)
	COM_INTERFACE_ENTRY(IMenuDef)
  COM_INTERFACE_ENTRY_FUNC(IID_IRootLevelMenu, 0, RootMenuQI)
  COM_INTERFACE_ENTRY_FUNC(IID_IShortcutMenu, 0, ShortcutMenuQI)
END_COM_MAP()

private:
  static HRESULT WINAPI RootMenuQI(void* pv, REFIID riid, LPVOID* ppv, DWORD_PTR dw)
  {
    CComObject<wrap_menu>* pMenu = static_cast<CComObject<wrap_menu>*>(pv);
    if (!(pMenu->m_isTopLevel))
    {
      *ppv = 0;
      return E_NOINTERFACE;
    }

    *ppv = static_cast<IRootLevelMenu*>(pMenu);
    pMenu->AddRef();

    return S_OK;
  }

  static HRESULT WINAPI ShortcutMenuQI(void* pv, REFIID riid, LPVOID* ppv, DWORD_PTR dw)
  {
    CComObject<wrap_menu>* pMenu = static_cast<CComObject<wrap_menu>*>(pv);
    if (!(pMenu->m_isShortcut))
    {
      *ppv = 0;
      return E_NOINTERFACE;
    }

    *ppv = static_cast<IShortcutMenu*>(pMenu);
    pMenu->AddRef();

    return S_OK;
  }
};