/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
#pragma once

#include "stdafx.h"
#include "utils.h"

// PythonExecuteWait -- turns cursor into hourglass and traps
// prints/tracebacks for display in the command line window
class PythonExecuteWaitNoCursor
{
public:
  PythonExecuteWaitNoCursor();
  ~PythonExecuteWaitNoCursor();
  void PumpError();

private:
  IGPCommandWindowAccessImplPtr m_ipPythonWindow;
  PyObject* m_pOldStdout;
  PyObject* m_pNewStdout;
  PyObject* m_pOldStderr;
  PyObject* m_pNewStderr;

  void WrapOutputStreams();
};

class PythonExecuteWait : public PythonExecuteWaitNoCursor
{
private:
  CWaitCursor m_waitCursor;
};