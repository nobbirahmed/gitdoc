/*
COPYRIGHT 1995-2012 ESRI
TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
Unpublished material - all rights reserved under the 
Copyright Laws of the United States and applicable international
laws, treaties, and conventions.
 
For additional information, contact:
Environmental Systems Research Institute, Inc.
Attn: Contracts and Legal Services Department
380 New York Street
Redlands, California, 92373
USA
 
email: contracts@esri.com
*/
// pythonaddins.cpp : Implementation of DLL Exports.


#include "stdafx.h"
#include "resource.h"
//#include "dllmain.h"
#include "AddInFactory.h"
#include "PythonAddinFunctions.h"
#include "ProgressDialog.h"

class CpythonaddinsModule : public CAtlDllModuleT< CpythonaddinsModule >
{
public :
};

CpythonaddinsModule _AtlModule;

// Used to determine whether the DLL can be unloaded by OLE

// DllRegisterServer - Adds entries to the system registry
STDAPI DllRegisterServer(void)
{
  // registers object, typelib and all interfaces in typelib
  //HRESULT hr = _AtlModule.DllRegisterServer();
	//return hr;
  return S_OK;
}


// DllUnregisterServer - Removes entries from the system registry
STDAPI DllUnregisterServer(void)
{
	//HRESULT hr = _AtlModule.DllUnregisterServer();
	//return hr;
  return S_OK;
}

// DllInstall - Adds/Removes entries to the system registry per user
//              per machine.	
STDAPI DllInstall(BOOL bInstall, LPCWSTR pszCmdLine)
{
  return S_OK;
}
/*
STDAPI DllInstall(BOOL bInstall, LPCWSTR pszCmdLine)
{
    HRESULT hr = E_FAIL;
    static const wchar_t szUserSwitch[] = _T("user");

    if (pszCmdLine != NULL)
    {
    	if (_wcsnicmp(pszCmdLine, szUserSwitch, _countof(szUserSwitch)) == 0)
    	{
    		AtlSetPerUserRegistration(true);
    	}
    }

    if (bInstall)
    {	
    	hr = DllRegisterServer();
    	if (FAILED(hr))
    	{	
    		DllUnregisterServer();
    	}
    }
    else
    {
    	hr = DllUnregisterServer();
    }

    return hr;
}*/


STDAPI GetAddInFactory(IUnknown** ppFactory)
{  
  //static AddInFactory* g_factory = NULL;
  static CComObjectGlobal<AddInFactory> g_factory;  
  return g_factory.QueryInterface(IID_IUnknown, (void**)ppFactory);
}

static PyMethodDef desktopaddins_functions[] = {
  {"OpenDialog", (PyCFunction)addinfunctions::OpenDialog, METH_VARARGS|METH_KEYWORDS, "OpenDialog({title}, {multiple_selection}, {starting_location}, {button_caption}, {filter}, {filter_label})"},
  {"SaveDialog", (PyCFunction)addinfunctions::SaveDialog, METH_VARARGS|METH_KEYWORDS, "SaveDialog({title}, {name_text}, {starting_location}, {filter}, {filter_label})"},
  {"GPToolDialog", (PyCFunction)addinfunctions::GPToolDialog, METH_VARARGS|METH_KEYWORDS, "GPToolDialog(toolbox, tool_name)"},
  {"MessageBox", (PyCFunction)addinfunctions::PopupMessageBox, METH_VARARGS|METH_KEYWORDS, "MessageBox(message, title, {mb_type})"},
  {"GetSelectedTOCLayerOrDataFrame", (PyCFunction)addinfunctions::GetSelectedTOCLayerOrDataFrame, METH_NOARGS, "GetSelectedTOCLayerOrDataFrame()"},
  {"GetSelectedCatalogWindowPath", (PyCFunction)addinfunctions::GetSelectedCatalogWindowPath, METH_NOARGS, "GetSelectedCatalogWindowPath()"},
  {"_WriteStringToPythonWindow", (PyCFunction)addinfunctions::WriteStringToPythonWindow, METH_VARARGS|METH_KEYWORDS, "WriteStringToPythonWindow(text, {start_newline}, {reprompt_when_done}, {is_error})"},
  {0, 0}
};

PyMODINIT_FUNC
initpythonaddins(void)
{
  PyObject *m;

  m = Py_InitModule("pythonaddins", desktopaddins_functions);
  if (m == NULL)
  {
    return;
  }

  PyTypeObject* pProgressType(progressdialogpythonobject::GetProgressDialogType());
  if (pProgressType && PyType_Ready(pProgressType) > -1)
  {
    PyObject* progressdialog(PyObject_CallObject((PyObject*)pProgressType, NULL));
    PyModule_AddObject(m, s_progressDialog, progressdialog);
  }
  else
  {
    PyErr_Clear();
    // PyModule_AddObject steals a reference, so add one to Py_None for it
    Py_INCREF(Py_None);
    PyModule_AddObject(m, s_progressDialog, Py_None);
  }

  CoInitialize(NULL);
}